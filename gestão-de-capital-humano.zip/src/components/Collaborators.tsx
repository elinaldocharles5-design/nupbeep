/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Collaborator } from '../types';
import { 
  User, Search, PlusCircle, CheckCircle, 
  Calendar, Mail, FileText, ChevronRight, Sparkles, Loader2 
} from 'lucide-react';

interface CollaboratorsProps {
  collaborators: Collaborator[];
  onAddCollaborator: (c: Omit<Collaborator, 'id'>) => void;
  onUpdateCollaborator: (c: Collaborator) => void;
}

export default function Collaborators({
  collaborators,
  onAddCollaborator,
  onUpdateCollaborator,
}: CollaboratorsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('Todos');
  const [selectedStatus, setSelectedStatus] = useState('Todos');
  const [selectedColabId, setSelectedColabId] = useState<string>(collaborators[0]?.id || '');
  const [isAdding, setIsAdding] = useState(false);

  // Form states for new collaborator
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newDept, setNewDept] = useState('Marketing');
  const [newEmail, setNewEmail] = useState('');
  const [newAdmissionDate, setNewAdmissionDate] = useState(new Date().toISOString().split('T')[0]);

  // AI PDI helper state
  const [isGeneratingPdi, setIsGeneratingPdi] = useState(false);

  // Edit states for existing collaborator
  const [isEditingDetails, setIsEditingDetails] = useState(false);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState('');
  const [editDept, setEditDept] = useState('Marketing');
  const [editEmail, setEditEmail] = useState('');
  const [editAdmissionDate, setEditAdmissionDate] = useState('');

  // Reset editing mode when selected collaborator changes
  React.useEffect(() => {
    setIsEditingDetails(false);
  }, [selectedColabId]);

  // Selected collaborator helper
  const selectedColab = collaborators.find((c) => c.id === selectedColabId);

  // Filter collaborators
  const filteredColabs = collaborators.filter((c) => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.role.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === 'Todos' || c.department === selectedDept;
    const matchesStatus = selectedStatus === 'Todos' || c.status === selectedStatus;
    return matchesSearch && matchesDept && matchesStatus;
  });

  const uniqueDepartments = ['Todos', ...Array.from(new Set(collaborators.map(c => c.department)))];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newRole || !newEmail) return;

    onAddCollaborator({
      name: newName,
      role: newRole,
      department: newDept,
      admissionDate: newAdmissionDate,
      email: newEmail,
      status: 'Ativo',
      performance: {
        productivity: 80,
        competence: 80,
        communication: 80,
        alignment: 80,
        lastReviewDate: new Date().toISOString().split('T')[0],
        pdiNotes: 'PDI Inicial: Alinhamento de metas da primeira fase de desenvolvimento do membro.'
      },
      engagement: {
        moraleScore: 4,
        lastSurveyDate: new Date().toISOString().split('T')[0],
        surveyFeedback: 'Integração bem-sucedida.'
      }
    });

    // Reset Form
    setNewName('');
    setNewRole('');
    setNewEmail('');
    setIsAdding(false);
  };

  const handleUpdatePerformance = (field: 'productivity' | 'competence' | 'communication' | 'alignment', value: number) => {
    if (!selectedColab) return;
    const updated = {
      ...selectedColab,
      performance: {
        ...selectedColab.performance,
        [field]: value,
        lastReviewDate: new Date().toISOString().split('T')[0]
      }
    };
    onUpdateCollaborator(updated);
  };

  const handleUpdatePDI = (text: string) => {
    if (!selectedColab) return;
    const updated = {
      ...selectedColab,
      performance: {
        ...selectedColab.performance,
        pdiNotes: text
      }
    };
    onUpdateCollaborator(updated);
  };

  const handleTriggerAiPdi = async () => {
    if (!selectedColab) return;
    setIsGeneratingPdi(true);
    try {
      const res = await fetch('/api/ai/optimize-pdi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: selectedColab.name,
          role: selectedColab.role,
          department: selectedColab.department,
          performance: selectedColab.performance,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        handleUpdatePDI(data.pdiPlan);
      } else {
        alert('Erro ao otimizar PDI com IA: ' + data.error);
      }
    } catch {
      alert('Erro na integração de IA para PDI.');
    } finally {
      setIsGeneratingPdi(false);
    }
  };

  const handleUpdateStatus = (status: 'Ativo' | 'Afastado' | 'Desligado') => {
    if (!selectedColab) return;
    const updated = {
      ...selectedColab,
      status
    };
    onUpdateCollaborator(updated);
  };

  const startEditing = () => {
    if (!selectedColab) return;
    setEditName(selectedColab.name);
    setEditRole(selectedColab.role);
    setEditDept(selectedColab.department);
    setEditEmail(selectedColab.email);
    setEditAdmissionDate(selectedColab.admissionDate);
    setIsEditingDetails(true);
  };

  const handleSaveDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedColab) return;
    onUpdateCollaborator({
      ...selectedColab,
      name: editName,
      role: editRole,
      department: editDept,
      email: editEmail,
      admissionDate: editAdmissionDate
    });
    setIsEditingDetails(false);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="collaborators-tab">
      
      {/* Header com Busca e Gatilho Adicionar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-gray-250">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Gestão de Equipes</h1>
          <p className="text-sm text-gray-500 mt-1">
            Gestão do ciclo profissional do membro, acompanhamento de competências técnicas e planos de PDI.
          </p>
        </div>
        <button
          id="add-collaborator-trigger"
          onClick={() => setIsAdding(!isAdding)}
          className="inline-flex items-center gap-2 px-4.5 py-2.5 rounded-lg text-sm font-semibold text-white bg-red-700 hover:bg-red-800 transition-colors shadow-xs cursor-pointer"
        >
          <PlusCircle className="w-5 h-5" />
          Registrar Novo Membro
        </button>
      </div>

      {/* Form de Criação de Novo Colaborador */}
      {isAdding && (
        <form 
          onSubmit={handleCreate} 
          id="add-collaborator-form" 
          className="p-6 bg-slate-50 border border-slate-205 rounded-xl space-y-4 animate-fade-in"
        >
          <h3 className="font-bold text-gray-950 text-base">Nova Admissão de Membro NUPBEEP</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Nome Completo</label>
              <input
                type="text"
                required
                placeholder="Ex. Amanda Bezerra"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-250 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Função / Cargo</label>
              <input
                type="text"
                required
                placeholder="Ex. Coordenadora de Projetos"
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-250 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Diretoria</label>
              <select
                value={newDept}
                onChange={(e) => setNewDept(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-250 rounded-lg text-sm focus:border-red-650"
              >
                <option value="Marketing">Marketing</option>
                <option value="Projetos e Eventos">Projetos e Eventos</option>
                <option value="Relações Externas">Relações Externas</option>
                <option value="Relações Internas">Relações Internas</option>
                <option value="Financeiro">Financeiro</option>
                <option value="Presidente">Presidente</option>
                <option value="Vice Presidente">Vice Presidente</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">E-mail de Contato</label>
              <input
                type="email"
                required
                placeholder="nome@nupbeep.org"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-250 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Início das Atividades</label>
              <input
                type="date"
                required
                value={newAdmissionDate}
                onChange={(e) => setNewAdmissionDate(e.target.value)}
                className="px-3 py-1.5 bg-white border border-gray-205 rounded-lg text-sm focus:border-red-650"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-sm text-gray-650 bg-white hover:bg-gray-100 border border-gray-200 rounded-lg transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-sm font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg transition-colors cursor-pointer"
              >
                Salvar Membro
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Seção Filtros e Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-fade-in" id="collaborators-viewport">
        
        {/* Painel Esquerdo: Lista de Nomes */}
        <div className="lg:col-span-4 bg-white border border-gray-100 rounded-2xl p-4 space-y-4 shadow-xs">
          
          {/* Caixa de Busca */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por nome ou cargo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-50/50 border border-gray-100 rounded-xl text-xs focus:bg-white focus:border-red-600 focus:outline-hidden"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Diretoria</label>
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full p-2 bg-gray-50 border border-gray-100 rounded-lg font-bold"
              >
                {uniqueDepartments.map((dept) => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full p-2 bg-gray-50 border border-gray-100 rounded-lg font-bold"
              >
                <option value="Todos">Todos</option>
                <option value="Ativo">Ativos</option>
                <option value="Afastado">Afastados</option>
                <option value="Desligado">Desligados</option>
              </select>
            </div>
          </div>

          {/* Lista em Scroll */}
          <div className="h-[420px] overflow-y-auto divide-y divide-gray-50 pr-1">
            {filteredColabs.length === 0 ? (
              <div className="text-center py-12 text-sm text-gray-400">Nenhum membro listado com estes filtros.</div>
            ) : (
              filteredColabs.map((c) => {
                const isSelected = c.id === selectedColabId;
                const statusColors = {
                  'Ativo': 'bg-green-100 text-green-700',
                  'Afastado': 'bg-amber-100 text-amber-700',
                  'Desligado': 'bg-red-100 text-red-700'
                };

                return (
                  <button
                    key={c.id}
                    id={`colab-item-${c.id}`}
                    onClick={() => setSelectedColabId(c.id)}
                    className={`w-full text-left p-3.5 flex items-center justify-between transition-all rounded-lg cursor-pointer ${
                      isSelected ? 'bg-red-50/50 border-r-3 border-red-750' : 'hover:bg-slate-50/50'
                    }`}
                  >
                    <div className="min-w-0 flex-1 pr-2">
                      <span className="font-bold text-sm text-gray-900 block truncate leading-tight">{c.name}</span>
                      <span className="text-[11px] text-gray-400 block truncate mt-0.5">{c.role} • <strong>{c.department}</strong></span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={`text-[9px] uppercase font-black px-1.5 py-0.5 rounded-full ${statusColors[c.status]}`}>
                        {c.status}
                      </span>
                      <ChevronRight className="w-4 h-4 text-gray-300" />
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Painel Direito: Competencias, PDI e Desempenho */}
        <div className="lg:col-span-8 bg-white border border-gray-100 rounded-2xl min-h-[560px] shadow-xs" id="colab-detail-panel">
          {selectedColab ? (
            <div className="divide-y divide-gray-100">
              
              {/* Box Top */}
              {isEditingDetails ? (
                <form onSubmit={handleSaveDetails} className="p-6 bg-slate-50/70 border-b border-gray-100 space-y-4 animate-fade-in">
                  <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Editar Informações Cadastrais</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Nome Completo</label>
                      <input
                        type="text"
                        required
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold focus:border-red-650 focus:outline-hidden text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Função / Cargo</label>
                      <input
                        type="text"
                        required
                        value={editRole}
                        onChange={(e) => setEditRole(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold focus:border-red-650 focus:outline-hidden text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Diretoria</label>
                      <select
                        value={editDept}
                        onChange={(e) => setEditDept(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800"
                      >
                        <option value="Marketing">Marketing</option>
                        <option value="Projetos e Eventos">Projetos e Eventos</option>
                        <option value="Relações Externas">Relações Externas</option>
                        <option value="Relações Internas">Relações Internas</option>
                        <option value="Financeiro">Financeiro</option>
                        <option value="Presidente">Presidente</option>
                        <option value="Vice Presidente">Vice Presidente</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">E-mail de Contato</label>
                      <input
                        type="email"
                        required
                        value={editEmail}
                        onChange={(e) => setEditEmail(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold focus:border-red-650 focus:outline-hidden text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Data de Admissão</label>
                      <input
                        type="date"
                        required
                        value={editAdmissionDate}
                        onChange={(e) => setEditAdmissionDate(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsEditingDetails(false)}
                      className="px-3.5 py-1.5 text-xs font-semibold text-slate-650 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg transition-colors cursor-pointer"
                    >
                      Salvar Alterações
                    </button>
                  </div>
                </form>
              ) : (
                <div className="p-6 bg-slate-50/40 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 bg-red-750 rounded-full flex items-center justify-center text-white text-sm font-black shadow-md shrink-0">
                      {selectedColab.name.split(' ').map(n=>n[0]).join('').substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h2 className="text-xl font-extrabold text-gray-950 leading-tight">{selectedColab.name}</h2>
                      <span className="text-xs text-red-700 font-bold block">{selectedColab.role} • Diretoria de {selectedColab.department}</span>
                      
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-gray-400 pt-1">
                        <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {selectedColab.email}</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> Admissão em {new Date(selectedColab.admissionDate).toLocaleDateString('pt-BR')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
                    <button
                      onClick={startEditing}
                      className="px-3 py-2 border border-red-200/50 hover:border-red-650 text-red-700 hover:bg-red-50/30 rounded-lg text-xs font-black transition-all cursor-pointer inline-flex items-center justify-center gap-1"
                    >
                      <span>✏️ Editar Cadastro</span>
                    </button>

                    <select 
                      value={selectedColab.status}
                      onChange={(e) => handleUpdateStatus(e.target.value as any)}
                      className="p-2 border border-gray-150 rounded-lg text-xs font-bold bg-white text-slate-800 cursor-pointer"
                    >
                      <option value="Ativo">🟢 Ativo</option>
                      <option value="Afastado">🟡 Afastado</option>
                      <option value="Desligado">🔴 Desligado (Desligamento)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Avaliação Multi-dimensional Slider */}
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between pb-1 border-b border-gray-50">
                  <h3 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                    Competências Individuais do Membro
                  </h3>
                  <span className="text-[10px] text-gray-400 font-bold">Ajuste os valores para remodelar o PDI</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
                  {/* Item 1 */}
                  <div className="space-y-1.5 bg-gray-50/50 p-3 rounded-lg border border-gray-50/50">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-gray-700">Entregas & Produtividade</span>
                      <span className="text-red-700">{selectedColab.performance.productivity}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="5"
                      value={selectedColab.performance.productivity}
                      onChange={(e) => handleUpdatePerformance('productivity', parseInt(e.target.value))}
                      className="w-full accent-red-750 cursor-pointer h-1.5 bg-gray-200 rounded-lg appearance-none"
                    />
                  </div>

                  {/* Item 2 */}
                  <div className="space-y-1.5 bg-gray-50/50 p-3 rounded-lg border border-gray-50/50">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-gray-700">Competência Técnica / Qualidade</span>
                      <span className="text-red-700">{selectedColab.performance.competence}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="5"
                      value={selectedColab.performance.competence}
                      onChange={(e) => handleUpdatePerformance('competence', parseInt(e.target.value))}
                      className="w-full accent-red-750 cursor-pointer h-1.5 bg-gray-200 rounded-lg appearance-none"
                    />
                  </div>

                  {/* Item 3 */}
                  <div className="space-y-1.5 bg-gray-50/50 p-3 rounded-lg border border-gray-50/50">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-gray-700">Comunicação & Liderança</span>
                      <span className="text-red-700">{selectedColab.performance.communication}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="5"
                      value={selectedColab.performance.communication}
                      onChange={(e) => handleUpdatePerformance('communication', parseInt(e.target.value))}
                      className="w-full accent-red-750 cursor-pointer h-1.5 bg-gray-200 rounded-lg appearance-none"
                    />
                  </div>

                  {/* Item 4 */}
                  <div className="space-y-1.5 bg-gray-50/50 p-3 rounded-lg border border-gray-50/50">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-gray-700">Alinhamento de Cultura</span>
                      <span className="text-red-700">{selectedColab.performance.alignment}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="5"
                      value={selectedColab.performance.alignment}
                      onChange={(e) => handleUpdatePerformance('alignment', parseInt(e.target.value))}
                      className="w-full accent-red-750 cursor-pointer h-1.5 bg-gray-200 rounded-lg appearance-none"
                    />
                  </div>
                </div>
              </div>

              {/* Plano de Desenvolvimento Individual (PDI) */}
              <div className="p-6 space-y-3.5">
                <div className="flex items-center justify-between pb-1 border-b border-gray-50">
                  <h3 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                    Plano de Desenvolvimento Individual (PDI)
                  </h3>
                  
                  <button
                    onClick={handleTriggerAiPdi}
                    disabled={isGeneratingPdi}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-red-700 hover:bg-red-800 transition-colors shadow-xs disabled:opacity-60 cursor-pointer"
                  >
                    {isGeneratingPdi ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        Otimizando PDI...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                        Recomendar Metas com Gemini AI
                      </>
                    )}
                  </button>
                </div>

                <div className="space-y-2">
                  <textarea
                    rows={6}
                    id="pdi-notes-textarea"
                    value={selectedColab.performance.pdiNotes || ''}
                    onChange={(e) => handleUpdatePDI(e.target.value)}
                    placeholder="Escreva aqui os combinados, metas académicas/técnicas, próximas ações e sugestões de plano de carreira coletadas nas 1:1s semanais."
                    className="w-full p-4 bg-gray-50/50 border border-gray-150 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:border-red-650 focus:outline-hidden leading-relaxed"
                  />
                  <div className="flex justify-between text-[11px] text-gray-400">
                    <span>O plano salva as mudanças de forma instantânea na base local.</span>
                    <span>Modificado em: {selectedColab.performance.lastReviewDate || 'Carregando...'}</span>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            <div className="p-12 text-center text-gray-400 h-full flex flex-col items-center justify-center">
              <User className="w-12 h-12 text-gray-300 mb-2" />
              Selecione um integrante na lista à esquerda para analisar o plano de carreira e PDI.
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
