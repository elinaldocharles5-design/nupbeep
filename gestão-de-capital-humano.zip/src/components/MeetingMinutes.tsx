/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MeetingMinute } from '../types';
import { 
  FileText, Calendar, Users, PlusCircle, Sparkles, 
  Trash2, Loader2, Bookmark, CheckSquare, List 
} from 'lucide-react';

interface MeetingMinutesProps {
  minutes: MeetingMinute[];
  onAddMinute: (m: Omit<MeetingMinute, 'id' | 'createdAt'>) => void;
  onUpdateMinute: (m: MeetingMinute) => void;
  onDeleteMinute: (minuteId: string) => void;
}

export default function MeetingMinutes({
  minutes,
  onAddMinute,
  onUpdateMinute,
  onDeleteMinute,
}: MeetingMinutesProps) {
  const [selectedMinuteId, setSelectedMinuteId] = useState<string>(minutes[0]?.id || '');
  const [isCreating, setIsCreating] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [participants, setParticipants] = useState('');
  const [rawNotes, setRawNotes] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  // Edit states for existing meeting minute
  const [isEditingMinute, setIsEditingMinute] = useState(false);
  const [editMinTitle, setEditMinTitle] = useState('');
  const [editMinDate, setEditMinDate] = useState('');
  const [editMinParticipants, setEditMinParticipants] = useState('');
  const [editMinRawNotes, setEditMinRawNotes] = useState('');
  const [editMinAiSummary, setEditMinAiSummary] = useState('');
  const [editMinActionItemsText, setEditMinActionItemsText] = useState('');

  // Reset editing mode when selected meeting Changes
  React.useEffect(() => {
    setIsEditingMinute(false);
  }, [selectedMinuteId]);

  // Selected minute helper
  const selectedMinute = minutes.find((m) => m.id === selectedMinuteId);

  const startEditingMinute = () => {
    if (!selectedMinute) return;
    setEditMinTitle(selectedMinute.title);
    setEditMinDate(selectedMinute.date);
    setEditMinParticipants(selectedMinute.participants);
    setEditMinRawNotes(selectedMinute.rawNotes);
    setEditMinAiSummary(selectedMinute.aiSummary || '');
    setEditMinActionItemsText((selectedMinute.actionItems || []).join('\n'));
    setIsEditingMinute(true);
  };

  const handleSaveMinuteDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMinute) return;
    const actionItems = editMinActionItemsText
      .split('\n')
      .map((item) => item.trim())
      .filter((item) => item.length > 0);

    onUpdateMinute({
      ...selectedMinute,
      title: editMinTitle,
      date: editMinDate,
      participants: editMinParticipants,
      rawNotes: editMinRawNotes,
      aiSummary: editMinAiSummary,
      actionItems
    });
    setIsEditingMinute(false);
  };

  const handleSubmitMinute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !rawNotes) return;

    setIsGenerating(true);

    try {
      // Direct call to our custom Express endpoint for AI generation
      const res = await fetch('/api/ai/meeting-minutes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, participants, rawNotes }),
      });

      const data = await res.json();

      if (res.ok) {
        onAddMinute({
          title,
          date,
          participants,
          rawNotes,
          aiSummary: data.aiSummary,
          actionItems: data.actionItems,
        });

        // Reset form
        setTitle('');
        setParticipants('');
        setRawNotes('');
        setIsCreating(false);
      } else {
        alert('Erro ao processar resumo de ata por IA: ' + data.error);
      }
    } catch (err) {
      console.error(err);
      alert('Falha interna de comunicação com a inteligência artificial.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="minutes-tab">
      
      {/* Intro Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Registro de Atas NUPBEEP</h1>
          <p className="text-sm text-gray-500 mt-1">
            Armazenamento unificado de decisões das diretorias e extração instantânea de tarefas com IA do NUPBEEP.
          </p>
        </div>
        <button
          id="toggle-create-minute-btn"
          onClick={() => setIsCreating(!isCreating)}
          className="inline-flex items-center gap-2 px-4.5 py-2.5 rounded-lg text-sm font-semibold text-red-750 bg-red-50 hover:bg-red-100 transition-colors shadow-xs cursor-pointer border border-red-100"
        >
          <PlusCircle className="w-5 h-5 text-red-750" />
          {isCreating ? 'Ver Arquivo de Atas' : 'Registrar Nova Reunião'}
        </button>
      </div>

      {isCreating ? (
        /* Form de Nova Reunião & Geração por IA */
        <form onSubmit={handleSubmitMinute} className="p-6 bg-white border border-gray-100 rounded-xl space-y-5 animate-fade-in" id="create-minute-form">
          <div className="flex items-center justify-between pb-3 border-b border-gray-50">
            <h2 className="font-bold text-gray-950 text-base flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-red-750" />
              Sessão de Registro e Redação da Ata
            </h2>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-750 rounded-full text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-red-550" />
              Processado por Gemini 3.5 AI
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">Título da Reunião</label>
              <input
                type="text"
                required
                placeholder="Ex. Reunião de Alinhamento de Projetos e Assessoria de Marketing"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 bg-gray-50/50 border border-gray-105 rounded-lg text-sm focus:bg-white focus:border-red-650 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 font-sans">Data do Encontro</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-gray-50/50 border border-gray-105 rounded-lg text-sm focus:bg-white focus:border-red-650 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">Membros Presentes / Participantes</label>
            <input
              type="text"
              placeholder="Ex: Amanda Bezerra (Projetos), Lucas Silva (Marketing), Mariana Sousa (Trainee)"
              value={participants}
              onChange={(e) => setParticipants(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50/50 border border-gray-105 rounded-lg text-sm focus:bg-white focus:border-red-650 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">Notas Brutas ou Transcrição de Voz</label>
            <textarea
              required
              rows={8}
              placeholder="Digite aqui as discussões chaves, decisões de Engenharia aprovadas e prazos de forma informal. A Inteligência Artificial irá padronizar, criar um resumo executivo de alta governança para o NUPBEEP e separar as tarefas de forma automática."
              value={rawNotes}
              onChange={(e) => setRawNotes(e.target.value)}
              className="w-full p-4.5 bg-gray-50/50 border border-gray-105 rounded-xl text-sm focus:bg-white focus:border-red-650 focus:outline-hidden leading-relaxed resize-y font-sans"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-4 py-2 text-sm text-gray-600 bg-white hover:bg-gray-100 border border-gray-200 rounded-lg transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              id="submit-minute-intelligence"
              disabled={isGenerating || !rawNotes}
              className="px-5 py-2.5 text-sm font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg transition-colors inline-flex items-center gap-2 shadow-xs disabled:opacity-50 cursor-pointer text-center justify-center"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Gemini está redigindo ata...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  Consolidar Ata por Inteligência Artificial
                </>
              )}
            </button>
          </div>
        </form>
      ) : (
        /* Arquivo de Atas Existentes: Split View */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-fade-in">
          
          {/* Histórico Esquerda */}
          <div className="lg:col-span-4 bg-white border border-gray-100 rounded-xl overflow-hidden shadow-xs h-[520px] flex flex-col">
            <div className="p-4 border-b border-gray-50 bg-gray-50/20">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Histórico de Reuniões ({minutes.length})</span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
              {minutes.length === 0 ? (
                <div className="p-8 text-center text-sm text-gray-400">Nenhuma ata registrada ainda.</div>
              ) : (
                minutes.map((m) => {
                  const isSelected = m.id === selectedMinuteId;
                  return (
                    <button
                      key={m.id}
                      id={`minute-sidebar-item-${m.id}`}
                      onClick={() => setSelectedMinuteId(m.id)}
                      className={`w-full text-left p-4 transition-all block group cursor-pointer ${
                        isSelected 
                          ? 'bg-red-50/40 border-r-3 border-red-750' 
                          : 'hover:bg-gray-50/30'
                      }`}
                    >
                      <span className="font-bold text-xs text-red-700 block mb-1">
                        {new Date(m.date).toLocaleDateString('pt-BR')}
                      </span>
                      <span className="font-bold text-sm text-gray-950 block truncate group-hover:text-red-750 transition-colors">
                        {m.title}
                      </span>
                      <span className="text-xs text-gray-400 block mt-1.5 truncate">
                        {m.participants || 'Sem participantes indicados'}
                      </span>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Conteúdo da Ata Selecionada Direita */}
          <div className="lg:col-span-8 bg-white border border-gray-100 rounded-xl min-h-[520px] shadow-xs" id="minute-viewport-panel">
            {selectedMinute ? (
              isEditingMinute ? (
                <form onSubmit={handleSaveMinuteDetails} className="p-6 space-y-4 divide-y divide-gray-100 animate-fade-in" id="edit-minute-form">
                  <div className="pb-4 space-y-4">
                    <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Editar Detalhes da Ata</h3>
                    
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Título da Reunião</label>
                      <input
                        type="text"
                        required
                        value={editMinTitle}
                        onChange={(e) => setEditMinTitle(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800 focus:border-red-650 focus:outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Data da Reunião</label>
                        <input
                          type="date"
                          required
                          value={editMinDate}
                          onChange={(e) => setEditMinDate(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Participantes (separados por vírgula)</label>
                        <input
                          type="text"
                          required
                          value={editMinParticipants}
                          onChange={(e) => setEditMinParticipants(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800 focus:border-red-650 focus:outline-hidden"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Resumo Executivo / Consolidação da Reunião</label>
                      <textarea
                        rows={4}
                        value={editMinAiSummary}
                        onChange={(e) => setEditMinAiSummary(e.target.value)}
                        placeholder="Insira aqui o resumo consolidado, decisões tomadas de forma resumida..."
                        className="w-full p-3 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800 focus:border-red-650 focus:outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Tarefas & Alinhamentos (uma por linha)</label>
                      <textarea
                        rows={4}
                        value={editMinActionItemsText}
                        onChange={(e) => setEditMinActionItemsText(e.target.value)}
                        placeholder="Ex. Implementar nova campanha de marketing (Responsável: Bruno, Prazo: 31/05)"
                        className="w-full p-3 bg-white border border-gray-250 rounded-lg text-xs font-semibold text-slate-800 focus:border-red-650 focus:outline-hidden font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Transcrições e Notas Brutas Originais</label>
                      <textarea
                        rows={5}
                        required
                        value={editMinRawNotes}
                        onChange={(e) => setEditMinRawNotes(e.target.value)}
                        placeholder="Cole as pautas cruas e as transcrições..."
                        className="w-full p-3 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800 focus:border-red-650 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <button
                      type="button"
                      onClick={() => setIsEditingMinute(false)}
                      className="px-4 py-2 text-xs font-semibold text-slate-650 bg-white border border-slate-205 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 text-xs font-bold text-white bg-red-750 hover:bg-red-800 rounded-lg transition-colors cursor-pointer shadow-xs"
                    >
                      Salvar Alterações
                    </button>
                  </div>
                </form>
              ) : (
                <div className="divide-y divide-gray-100 animate-fade-in">
                  
                  {/* Header Port */}
                  <div className="p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-50/30">
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-red-700 block">Ata Consolidada Oficial</span>
                      <h2 className="text-xl font-black text-gray-950 leading-tight">{selectedMinute.title}</h2>
                      
                      <div className="flex flex-wrap gap-y-1 gap-x-4 text-xs text-gray-400 pt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-gray-400" />
                          {new Date(selectedMinute.date).toLocaleDateString('pt-BR')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-gray-400" />
                          Ata de {selectedMinute.participants.split(',').length} Integrantes
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-start shrink-0">
                      <button
                        onClick={startEditingMinute}
                        className="px-3.5 py-2 border border-red-200 hover:border-red-650 text-red-700 hover:bg-red-50/30 rounded-lg text-xs font-black transition-all cursor-pointer inline-flex items-center gap-1.5"
                        title="Editar Ata de Reunião"
                      >
                        ✏️ Editar
                      </button>

                      <button
                        id="delete-minute-trigger"
                        onClick={() => {
                          if (confirm('Tem certeza de que deseja deletar permanentemente esta ata?')) {
                            onDeleteMinute(selectedMinute.id);
                            const remaining = minutes.filter((x) => x.id !== selectedMinute.id);
                            if (remaining.length > 0) {
                              setSelectedMinuteId(remaining[0].id);
                            } else {
                              setSelectedMinuteId('');
                            }
                          }
                        }}
                        className="p-2 text-gray-450 hover:text-red-650 bg-white hover:bg-red-50 border border-gray-100 rounded-lg transition-colors cursor-pointer"
                        title="Remover Ata de Reunião"
                      >
                        <Trash2 className="w-4.5 h-4.5" />
                      </button>
                    </div>
                  </div>

                  {/* Resumo da IA */}
                  {selectedMinute.aiSummary && (
                    <div className="p-6 bg-red-50/10 space-y-3" id="minute-ai-summary-viewport">
                      <h3 className="text-xs font-extrabold text-red-900 uppercase tracking-widest flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-red-700 animate-pulse" />
                        Resumo Executivo Gerado por Gemini IA
                      </h3>
                      <p className="text-sm font-medium text-slate-800 leading-relaxed bg-white p-4.5 rounded-xl border border-red-100">
                        {selectedMinute.aiSummary}
                      </p>
                    </div>
                  )}

                  {/* Itens de Ação checklists */}
                  {selectedMinute.actionItems && selectedMinute.actionItems.length > 0 && (
                    <div className="p-6 space-y-3.5" id="minute-ai-tasks-viewport">
                      <h3 className="text-xs font-extrabold text-red-900 uppercase tracking-widest flex items-center gap-2">
                        <CheckSquare className="w-4 h-4 text-red-700" />
                        Tarefas & Alinhamentos Criados
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                        {selectedMinute.actionItems.map((item, idx) => (
                          <div key={idx} className="p-3 bg-gray-50/50 border border-gray-50 rounded-lg flex items-start gap-2.5">
                            <span className="w-5 h-5 bg-red-100 text-red-700 text-xs font-black rounded-full flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="text-xs font-medium text-gray-750 leading-relaxed">
                              {item}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Notas Brutas */}
                  <div className="p-6 space-y-3">
                    <h3 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                      <List className="w-4 h-4" />
                      Transcrição e Notas Brutas Originais
                    </h3>
                    <div className="p-4 bg-slate-50 border border-gray-100 text-slate-600 text-xs rounded-lg whitespace-pre-line leading-relaxed h-32 overflow-y-auto">
                      {selectedMinute.rawNotes}
                    </div>
                  </div>

                </div>
              )
            ) : (
              <div className="p-12 text-center text-gray-400 h-full flex flex-col items-center justify-center">
                <FileText className="w-12 h-12 text-gray-300 mb-2" />
                Selecione uma ata da lista à esquerda para analisar o plano estratégico.
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
