/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { OnboardingTalent } from '../types';
import { 
  Sparkles, CheckCircle, Mail, Calendar, Briefcase, PlusCircle, 
  Layers, CheckSquare, Loader2, Award, ArrowUpRight
} from 'lucide-react';

interface OnboardingProps {
  talents: OnboardingTalent[];
  onAddTalent: (t: Omit<OnboardingTalent, 'id' | 'progress'>) => void;
  onUpdateTalent: (t: OnboardingTalent) => void;
  onPromoteToCollaborator: (talentId: string) => void;
}

export default function Onboarding({
  talents,
  onAddTalent,
  onUpdateTalent,
  onPromoteToCollaborator,
}: OnboardingProps) {
  const [selectedTalentId, setSelectedTalentId] = useState<string>(talents[0]?.id || '');
  const [isAdding, setIsAdding] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [department, setDepartment] = useState('Marketing');
  const [email, setEmail] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [generatingAi, setGeneratingAi] = useState(false);

  // Selected talent helper
  const selectedTalent = talents.find((t) => t.id === selectedTalentId);

  // Submit new talent
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !role || !email) return;

    setGeneratingAi(true);

    try {
      // Call endpoint to generate standard checklists and customized AI milestones instantly!
      const res = await fetch('/api/ai/onboarding-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, role, department }),
      });

      const data = await res.json();

      const avatarColors = ['#b91c1c', '#0f172a', '#ea580c', '#334155', '#450a0a'];
      const randomColor = avatarColors[Math.floor(Math.random() * avatarColors.length)];

      onAddTalent({
        name,
        role,
        department,
        startDate,
        email,
        avatarColor: randomColor,
        tasks: data.tasks || [
          { id: 't1', title: 'Enviar documentação do processo seletivo NUPBEEP', category: 'Documentos', completed: false },
          { id: 't2', title: 'Entrega do kit de boas-vindas e camiseta do núcleo', category: 'Equipamentos', completed: false },
          { id: 't3', title: 'Importar credenciais de acesso ao Drive e canais internos', category: 'Acessos', completed: false },
          { id: 't4', title: 'Reunião de boas-vindas com o padrinho da Diretoria designado', category: 'Integração', completed: false }
        ],
        aiPlan: data.aiPlan || 'Boas-vindas ao NUPBEEP! Trilha recomendada criada.'
      });

      // Clear states
      setName('');
      setRole('');
      setEmail('');
      setIsAdding(false);
    } catch (err) {
      console.error(err);
      alert('Falha interna ao planejar o onboarding por IA. Tente carregar novamente.');
    } finally {
      setGeneratingAi(false);
    }
  };

  const handleToggleTask = (taskId: string) => {
    if (!selectedTalent) return;

    const updatedTasks = selectedTalent.tasks.map((task) => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );

    const completedCount = updatedTasks.filter((t) => t.completed).length;
    const progress = Math.round((completedCount / updatedTasks.length) * 100);

    const updatedTalent = {
      ...selectedTalent,
      tasks: updatedTasks,
      progress,
    };

    onUpdateTalent(updatedTalent);
  };

  // Edit states for existing onboarding talent
  const [isEditingOnb, setIsEditingOnb] = useState(false);
  const [editOnbName, setEditOnbName] = useState('');
  const [editOnbRole, setEditOnbRole] = useState('');
  const [editOnbDept, setEditOnbDept] = useState('Marketing');
  const [editOnbEmail, setEditOnbEmail] = useState('');
  const [editOnbStartDate, setEditOnbStartDate] = useState('');

  // Reset editing mode when candidate selection shifts
  React.useEffect(() => {
    setIsEditingOnb(false);
  }, [selectedTalentId]);

  const startEditingOnb = () => {
    if (!selectedTalent) return;
    setEditOnbName(selectedTalent.name);
    setEditOnbRole(selectedTalent.role);
    setEditOnbDept(selectedTalent.department);
    setEditOnbEmail(selectedTalent.email);
    setEditOnbStartDate(selectedTalent.startDate);
    setIsEditingOnb(true);
  };

  const handleSaveOnbDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTalent) return;
    onUpdateTalent({
      ...selectedTalent,
      name: editOnbName,
      role: editOnbRole,
      department: editOnbDept,
      email: editOnbEmail,
      startDate: editOnbStartDate
    });
    setIsEditingOnb(false);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="onboarding-tab">
      
      {/* Intro Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Onboarding de Integrantes</h1>
          <p className="text-sm text-gray-500 mt-1 font-sans">
            Construção estruturada das etapas e trilhas de integração para novos assessores e diretores do NUPBEEP.
          </p>
        </div>
        <button
          id="toggle-add-talent-btn"
          onClick={() => setIsAdding(!isAdding)}
          className="inline-flex items-center gap-2 px-4.5 py-2.5 rounded-lg text-sm font-semibold text-white bg-red-700 hover:bg-red-800 transition-colors shadow-xs cursor-pointer"
        >
          <PlusCircle className="w-5 h-5 animate-pulse" />
          Registrar Admissão no NUPBEEP
        </button>
      </div>

      {isAdding && (
        /* Formulario para adicionar novo onboarding do zero com IA */
        <form onSubmit={handleSubmit} className="p-6 bg-slate-50 border border-slate-250/60 rounded-xl space-y-4 animate-fade-in" id="add-talent-form">
          <div className="flex items-center gap-1.5 pb-2 border-b border-gray-200">
            <Sparkles className="w-5 h-5 text-red-700" />
            <h3 className="font-bold text-gray-950 text-sm">Novo Membro com Trilha Gerada por IA do NUPBEEP</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Nome do Membro</label>
              <input
                type="text"
                required
                placeholder="Ex. Amanda Bezerra"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Cargo / Função</label>
              <input
                type="text"
                required
                placeholder="Ex. Assessora de Projetos"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1 font-sans">Diretoria</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              >
                <option value="Marketing">Marketing</option>
                <option value="Projetos e Eventos">Projetos e Eventos</option>
                <option value="Relações Externas">Relações Externas</option>
                <option value="Relações Internas">Relações Internas</option>
                <option value="Financeiro">Financeiro</option>
                <option value="Presidente">Presidente</option>
                <option value="Vice Presidente">Vice Presidente</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">E-mail de Contato</label>
              <input
                type="email"
                required
                placeholder="nome@nupbeep.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:border-red-650 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            <div className="md:col-span-1">
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Início da Integração</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:border-red-650"
              />
            </div>
            
            <div className="md:col-span-2 flex items-end justify-end gap-2 text-right">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-sm text-gray-650 bg-white hover:bg-gray-100 border border-gray-200 rounded-lg transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              
              <button
                type="submit"
                id="generate-onboard-submit"
                disabled={generatingAi || !name || !role}
                className="px-5 py-2 text-sm font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg transition-colors inline-flex items-center gap-2 shadow-xs disabled:opacity-60 cursor-pointer"
              >
                {generatingAi ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Gerando trilha inteligente...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                    Criar Roteiro NUPBEEP AI
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Split-View dos Onboardings Ativos */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-fade-in">
        
        {/* Lista de Trainees / Novos integrados (Esquerda) */}
        <div className="lg:col-span-4 bg-white border border-gray-100 rounded-xl overflow-hidden shadow-xs h-[520px] flex flex-col">
          <div className="p-4 border-b border-gray-55 bg-gray-50/25">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Integrantes em Clima de Onboarding ({talents.length})</span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
            {talents.length === 0 ? (
              <div className="p-8 text-center text-sm text-gray-400">Nenhum onboarding pendente na base de dados.</div>
            ) : (
              talents.map((t) => {
                const isSelected = t.id === selectedTalentId;
                return (
                  <button
                    key={t.id}
                    id={`onboard-sidebar-item-${t.id}`}
                    onClick={() => setSelectedTalentId(t.id)}
                    className={`w-full text-left p-4 transition-all block group cursor-pointer ${
                      isSelected 
                        ? 'bg-red-50/50 border-r-3 border-red-700' 
                        : 'hover:bg-gray-50/10'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-black shadow-inner" style={{ backgroundColor: t.avatarColor || '#b91c1c' }}>
                        {t.name.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="font-bold text-sm text-gray-900 block group-hover:text-red-700 transition-colors truncate">{t.name}</span>
                        <span className="text-[11px] text-gray-400 block truncate">{t.role} • <strong>{t.department}</strong></span>
                      </div>
                      <span className="text-xs font-bold text-red-700 block shrink-0">{t.progress}%</span>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Detalhes do Onboarding Selecionado (Direita) */}
        <div className="lg:col-span-8 bg-white border border-gray-100 rounded-xl min-h-[520px] shadow-xs" id="onboarding-viewport">
          {selectedTalent ? (
            <div className="divide-y divide-gray-100" id="onboard-detail-card">
              
              {/* Box Top */}
              {isEditingOnb ? (
                <form onSubmit={handleSaveOnbDetails} className="p-6 bg-slate-50/70 border-b border-gray-100 space-y-4 animate-fade-in">
                  <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Editar Informações do Integrante</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Nome Completo</label>
                      <input
                        type="text"
                        required
                        value={editOnbName}
                        onChange={(e) => setEditOnbName(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold focus:border-red-650 focus:outline-hidden text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Função / Cargo</label>
                      <input
                        type="text"
                        required
                        value={editOnbRole}
                        onChange={(e) => setEditOnbRole(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold focus:border-red-650 focus:outline-hidden text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Diretoria</label>
                      <select
                        value={editOnbDept}
                        onChange={(e) => setEditOnbDept(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800"
                      >
                        <option value="Marketing">Marketing</option>
                        <option value="Projetos e Eventos">Projetos e Eventos</option>
                        <option value="Relações Externas">Relações Externas</option>
                        <option value="Relações Internas">Relações Internas</option>
                        <option value="Financeiro">Financeiro</option>
                        <option value="Presidente">Presidente</option>
                        <option value="Vice Presidente">Vice Presidente</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">E-mail de Contato</label>
                      <input
                        type="email"
                        required
                        value={editOnbEmail}
                        onChange={(e) => setEditOnbEmail(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold focus:border-red-650 focus:outline-hidden text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Início das Atividades</label>
                      <input
                        type="date"
                        required
                        value={editOnbStartDate}
                        onChange={(e) => setEditOnbStartDate(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs font-bold text-slate-800"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsEditingOnb(false)}
                      className="px-3.5 py-1.5 text-xs font-semibold text-slate-650 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-bold text-white bg-red-700 hover:bg-red-800 rounded-lg transition-colors cursor-pointer"
                    >
                      Salvar Alterações
                    </button>
                  </div>
                </form>
              ) : (
                <div className="p-6 bg-slate-50/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center text-white text-sm font-black shadow-md shrink-0" style={{ backgroundColor: selectedTalent.avatarColor || '#b91c1c' }}>
                      {selectedTalent.name.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-xl font-extrabold text-gray-950 leading-tight">{selectedTalent.name}</h2>
                        <button
                          onClick={startEditingOnb}
                          className="px-2 py-0.5 border border-red-200 hover:border-red-650 text-red-700 hover:bg-red-50/50 rounded-md text-[10px] font-black transition-all cursor-pointer inline-flex items-center gap-1 shrink-0"
                        >
                          <span>✏️ Editar</span>
                        </button>
                      </div>
                      <span className="text-xs text-red-700 font-bold block">{selectedTalent.role} • Diretoria de {selectedTalent.department}</span>
                      
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-gray-400 pt-1">
                        <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {selectedTalent.email}</span>
                        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> Admissão em {new Date(selectedTalent.startDate).toLocaleDateString('pt-BR')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-black text-red-700">{selectedTalent.progress}% Concluído</span>
                    <div className="w-32 bg-gray-200 h-2 rounded-full mt-1.5 overflow-hidden border border-gray-50/50">
                      <div className="bg-gradient-to-r from-red-650 to-red-700 h-2 rounded-full transition-all duration-350" style={{ width: `${selectedTalent.progress}%` }}></div>
                    </div>
                  </div>
                </div>
              )}

              {/* Checklist de Tarefas Administrativas e de Integração */}
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-gray-50">
                  <h3 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest flex items-center gap-1.5">
                    <CheckSquare className="w-4.5 h-4.5 text-red-700" />
                    Termos de Atração & Atividades de Integração
                  </h3>
                  <span className="text-[10px] text-slate-400 font-bold">Marque as atividades conforme sua conclusão</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-35">
                  {selectedTalent.tasks.map((task) => (
                    <label 
                      key={task.id} 
                      className={`p-3.5 rounded-lg border text-xs font-bold leading-relaxed flex items-start gap-3 transition-all cursor-pointer ${
                        task.completed 
                          ? 'bg-emerald-50/55 border-emerald-100 text-slate-550 line-through' 
                          : 'bg-white border-gray-100 text-gray-700 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={() => handleToggleTask(task.id)}
                        className="w-4 h-4 text-red-750 border-gray-200 rounded-sm focus:ring-red-600 mt-0.5 cursor-pointer"
                      />
                      <div>
                        <span className="text-[9px] uppercase font-black text-red-650 block mb-0.5">{task.category}</span>
                        <span>{task.title}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Sugestões do Plano gerado por Inteligência Artificial */}
              {selectedTalent.aiPlan && (
                <div className="p-6 bg-slate-50/50 space-y-3">
                  <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-red-700" />
                    Trilha Prática de Engenharia de Produção NUPBEEP (AI)
                  </h3>
                  <div className="p-5 bg-white border border-red-100 rounded-xl leading-relaxed whitespace-pre-line text-xs font-bold text-slate-800 shadow-xs">
                    {selectedTalent.aiPlan}
                  </div>
                </div>
              )}

              {/* Botao de Efetivação Promocao do Trainee para Membro Pleno */}
              <div className="p-6 flex justify-end">
                <button
                  id="promote-onboard-member-btn"
                  onClick={() => {
                    if (confirm(`Deseja efetivar ${selectedTalent.name} como membro ativo pleno do NUPBEEP?`)) {
                      onPromoteToCollaborator(selectedTalent.id);
                    }
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-red-750 hover:bg-red-800 text-white font-black rounded-lg text-xs transition-colors shadow-sm cursor-pointer"
                >
                  <Award className="w-4 h-4 text-white" />
                  Efetivar Novo Integrante Pleno
                  <ArrowUpRight className="w-4 h-4 text-white" />
                </button>
              </div>

            </div>
          ) : (
            <div className="p-12 text-center text-gray-400 h-full flex flex-col items-center justify-center">
              <Layers className="w-12 h-12 text-gray-300 mb-2" />
              Selecione um membro em onboarding para monitorar as entregas e checklists.
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
