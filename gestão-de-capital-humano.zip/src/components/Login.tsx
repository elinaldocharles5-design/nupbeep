/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Lock, Mail, User, Sparkles, CheckCircle, ArrowRight, 
  ShieldAlert, Info, Key, RefreshCw, Eye, EyeOff
} from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (user: { name: string; email: string }) => void;
}

interface SavedUser {
  name: string;
  email: string;
  passwordHash: string;
}

// Inline custom SVG rendering the NUPBEEP Paraíba Logo (Gear and upward rising Arrow)
export function NupbeepLogo({ className = "w-12 h-12" }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" id="nupbeep-brand-svg">
      <defs>
        <linearGradient id="nupbeepRedGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#180002" />
          <stop offset="50%" stopColor="#a70b13" />
          <stop offset="100%" stopColor="#e61420" />
        </linearGradient>
      </defs>
      {/* Outer Gear (with industrial gear teeth) */}
      <g>
        {/* Gear Outer Teeth */}
        <circle cx="50" cy="50" r="34" stroke="url(#nupbeepRedGrad)" strokeWidth="6" strokeDasharray="14 4.5" />
        {/* Gear Body */}
        <circle cx="50" cy="50" r="28" fill="url(#nupbeepRedGrad)" stroke="#111" strokeWidth="1" />
        {/* Inner track representing wheel structure */}
        <circle cx="50" cy="50" r="21" stroke="#ffffff" strokeWidth="1.8" fill="none" />
        {/* Clock/Subdivision indicators */}
        <circle cx="50" cy="50" r="16" stroke="#ffffff" strokeWidth="0.8" strokeDasharray="2 3" fill="none" />
        
        {/* P:B text printed inside top and bottom of inner wheel */}
        <text x="50" y="41" fontSize="10" fontFamily="sans-serif" fontWeight="900" fill="#ffffff" textAnchor="middle" letterSpacing="0.5">P:B</text>
        <text x="50" y="66" fontSize="10" fontFamily="sans-serif" fontWeight="900" fill="#ffffff" textAnchor="middle" letterSpacing="0.5">P:B</text>

        {/* Dynamic spokes */}
        <line x1="28" y1="50" x2="33" y2="50" stroke="#ffffff" strokeWidth="1.5" />
        <line x1="67" y1="50" x2="72" y2="50" stroke="#ffffff" strokeWidth="1.5" />
        <line x1="50" y1="28" x2="50" y2="33" stroke="#ffffff" strokeWidth="1.5" />
        <line x1="50" y1="67" x2="50" y2="72" stroke="#ffffff" strokeWidth="1.5" />
      </g>

      {/* Upward zigzag arrow traversing the entire structure (Bottom/Left to Top/Right) */}
      <path 
        d="M 23 72 L 44 47 L 55 53 L 83 25 L 79 40 L 86 22 L 68 25 L 75 33 L 53 59 L 42 53 ZM 23 72" 
        fill="#ffffff" 
        stroke="#111111" 
        strokeWidth="1.2" 
        strokeLinejoin="miter"
      />
    </svg>
  );
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetEmail, setResetEmail] = useState('');

  // Simulation parameters
  const [simulationStep, setSimulationStep] = useState<number>(1);
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    const existingUsers = localStorage.getItem('hcm_users');
    if (!existingUsers) {
      const defaultUsers: SavedUser[] = [
        {
          name: 'Coordenador NUPBEEP',
          email: 'admin@empresa.com',
          passwordHash: 'admin123'
        }
      ];
      localStorage.setItem('hcm_users', JSON.stringify(defaultUsers));
    }
  }, []);

  const getUsers = (): SavedUser[] => {
    try {
      const u = localStorage.getItem('hcm_users');
      return u ? JSON.parse(u) : [];
    } catch {
      return [];
    }
  };

  const saveUsers = (users: SavedUser[]) => {
    localStorage.setItem('hcm_users', JSON.stringify(users));
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const trimmedEmail = email.trim().toLowerCase();

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: trimmedEmail, password })
      });

      if (response.ok) {
        const data = await response.json();
        // Sync to local storage to ensure client is cached
        const users = getUsers();
        if (!users.some(u => u.email.toLowerCase() === trimmedEmail)) {
          users.push({
            name: data.user.name,
            email: trimmedEmail,
            passwordHash: password
          });
          saveUsers(users);
        }
        
        setSuccess('Autenticação realizada com sucesso!');
        setTimeout(() => {
          onLoginSuccess({ name: data.user.name, email: data.user.email });
        }, 800);
        return;
      } else {
        const errData = await response.json().catch(() => ({}));
        
        // CHECK LOCAL STORAGE FALLBACK FIRST before displaying error
        const users = getUsers();
        const matchedUser = users.find(u => u.email.toLowerCase() === trimmedEmail && u.passwordHash === password);
        if (matchedUser) {
          // Sync back to server in the background so the server remembers them
          fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: matchedUser.name, email: trimmedEmail, password })
          }).catch(() => {});

          setSuccess('Autenticação realizada com sucesso (Sincronizado)!');
          setTimeout(() => {
            onLoginSuccess({ name: matchedUser.name, email: matchedUser.email });
          }, 800);
          return;
        }

        setError(errData.error || 'E-mail ou senha incorretos.');
        setIsLoading(false);
        return;
      }
    } catch (err) {
      console.warn('Backend offline, utilizando banco local (localStorage):', err);
    }

    // FALLBACK TO LOCAL STORAGE
    setTimeout(() => {
      const users = getUsers();
      const matchedUser = users.find(u => u.email.toLowerCase() === trimmedEmail && u.passwordHash === password);

      if (matchedUser) {
        setSuccess('Autenticação realizada com sucesso!');
        setTimeout(() => {
          onLoginSuccess({ name: matchedUser.name, email: matchedUser.email });
        }, 1000);
      } else {
        setError('E-mail ou senha incorretos.');
        setIsLoading(false);
      }
    }, 800);
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!name.trim() || !email.trim() || !password || !confirmPassword) {
      setError('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    if (password !== confirmPassword) {
      setError('As senhas digitadas não coincidem.');
      return;
    }

    if (password.length < 4) {
      setError('A senha deve conter pelo menos 4 caracteres.');
      return;
    }

    setIsLoading(true);
    const targetEmail = email.trim().toLowerCase();

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), email: targetEmail, password })
      });

      if (response.ok) {
        const data = await response.json();
        // Sync to local storage
        const users = getUsers();
        if (!users.some(u => u.email.toLowerCase() === targetEmail)) {
          users.push({
            name: name.trim(),
            email: targetEmail,
            passwordHash: password
          });
          saveUsers(users);
        }

        setSuccess('Conta criada e sincronizada com sucesso! Faça login para acessar o painel.');
        setIsLoading(false);
        setName('');
        setEmail('');
        setPassword('');
        setConfirmPassword('');
        setTimeout(() => {
          setSuccess('');
          setActiveTab('signin');
        }, 2000);
        return;
      } else {
        const errData = await response.json().catch(() => ({}));
        setError(errData.error || 'Erro ao registrar no servidor.');
        setIsLoading(false);
        return;
      }
    } catch (err) {
      console.warn('Backend offline, registrando no banco local (localStorage):', err);
    }

    // FALLBACK TO LOCAL STORAGE
    setTimeout(() => {
      const users = getUsers();
      const userExists = users.some(u => u.email.toLowerCase() === targetEmail);

      if (userExists) {
        setError('Este e-mail já está cadastrado em nossa base.');
        setIsLoading(false);
        return;
      }

      const newUser: SavedUser = {
        name: name.trim(),
        email: targetEmail,
        passwordHash: password
      };

      users.push(newUser);
      saveUsers(users);

      setSuccess('Conta criada localmente com sucesso! Faça login para acessar o painel.');
      setIsLoading(false);
      
      setName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setTimeout(() => {
        setSuccess('');
        setActiveTab('signin');
      }, 2000);
    }, 1000);
  };

  const handleResetRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!resetEmail.trim()) {
      setError('Insira um e-mail válido para a redefinição.');
      return;
    }

    setIsLoading(true);
    const targetEmail = resetEmail.trim().toLowerCase();

    try {
      const response = await fetch('/api/auth/forgot-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail })
      });

      if (response.ok) {
        setIsLoading(false);
        setSimulationStep(2);
        setSuccess('Conta válida encontrada no servidor de dados! Digite a nova senha de acesso abaixo.');
        return;
      } else {
        const errData = await response.json().catch(() => ({}));
        setError(errData.error || 'E-mail não encontrado na base de dados global.');
        setIsLoading(false);
        return;
      }
    } catch (err) {
      console.warn('Backend offline, consultando local:', err);
    }

    // FALLBACK TO LOCAL STORAGE
    setTimeout(() => {
      const users = getUsers();
      const userExists = users.some(u => u.email.toLowerCase() === targetEmail);

      if (!userExists) {
        setError('O e-mail informado não está cadastrado em nossa plataforma.');
        setIsLoading(false);
        return;
      }

      setIsLoading(false);
      setSimulationStep(2);
      setSuccess('Conta válida (Modo Local)! Digite sua nova senha de acesso abaixo.');
    }, 1000);
  };

  const handleSaveNewPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (newPassword.length < 4) {
      setError('A nova senha deve possuir no mínimo 4 caracteres.');
      return;
    }

    setIsLoading(true);
    const targetEmail = resetEmail.trim().toLowerCase();

    try {
      const response = await fetch('/api/auth/forgot-reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail, newPassword })
      });

      if (response.ok) {
        // Sync local storage
        const users = getUsers();
        const updatedUsers = users.map(u => {
          if (u.email.toLowerCase() === targetEmail) {
            return { ...u, passwordHash: newPassword };
          }
          return u;
        });
        saveUsers(updatedUsers);

        setIsLoading(false);
        setSuccess('Senha redefinida com sucesso no servidor e no navegador!');
        
        setTimeout(() => {
          setSuccess('');
          setResetEmail('');
          setNewPassword('');
          setSimulationStep(1);
          setActiveTab('signin');
        }, 1500);
        return;
      } else {
        const errData = await response.json().catch(() => ({}));
        setError(errData.error || 'Erro ao sincronizar nova senha com o servidor.');
        setIsLoading(false);
        return;
      }
    } catch (err) {
      console.warn('Backend offline, salvando localmente:', err);
    }

    // FALLBACK TO LOCAL STORAGE
    setTimeout(() => {
      const users = getUsers();
      const updatedUsers = users.map(u => {
        if (u.email.toLowerCase() === targetEmail) {
          return { ...u, passwordHash: newPassword };
        }
        return u;
      });

      saveUsers(updatedUsers);
      setIsLoading(false);
      setSuccess('Senha redefinida localmente com sucesso!');
      
      setTimeout(() => {
        setSuccess('');
        setResetEmail('');
        setNewPassword('');
        setSimulationStep(1);
        setActiveTab('signin');
      }, 1500);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden font-sans" id="login-module">
      {/* Background visual brand details */}
      <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-red-850/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row min-h-[580px]" id="login-container">
        
        {/* Left Section: Branding & Slogan */}
        <div className="md:w-1/2 bg-gradient-to-br from-slate-950 via-slate-900 to-[#1e0305] p-8 flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800 relative overflow-hidden">
          <div className="absolute inset-0 opacity-5 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
          
          <div className="relative z-10 animate-fade-in">
            <div className="flex items-center gap-3 mb-8">
              <NupbeepLogo className="w-14 h-14 shrink-0" />
              <div>
                <span className="font-extrabold text-xl text-white tracking-tight block">NUPBEEP Paraíba</span>
                <span className="text-[10px] uppercase font-bold text-red-500 block tracking-wider leading-none mt-1">
                  Núcleo de Estudantes de Engenharia de Produção
                </span>
              </div>
            </div>

            <div className="space-y-4 my-10">
              <h1 className="text-2xl lg:text-3xl font-black text-white tracking-tight leading-tight">
                Controle Estratégico & Gestão de Pessoas
              </h1>
              <p className="text-xs lg:text-sm text-slate-300 leading-relaxed font-normal">
                Faça o acompanhamento integrado das métricas de turnover, planos de desenvolvimento (PDI) automatizados com Gemini AI, registros de atas e checklists de onboarding de novos integrantes.
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-6 border-t border-slate-800/60 relative z-10 text-xs text-red-400">
            <p className="text-[10px] text-slate-500 text-center leading-relaxed">
              Sistema Customizado de Engenharia de Produção • NUPBEEP PB
            </p>
          </div>
        </div>

        {/* Right Section: Interactive Authentication Forms */}
        <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center bg-slate-900" id="login-viewport">
          
          <div className="flex items-center justify-between border-b border-slate-800 pb-5 mb-5">
            <div>
              <h2 className="text-xl font-extrabold text-white tracking-tight">
                {activeTab === 'signin' && 'Acessar Conta'}
                {activeTab === 'signup' && 'Criar Nova Conta'}
                {activeTab === 'forgot' && 'Recuperar Acesso'}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {activeTab === 'signin' && 'Insira suas credenciais para verificar acessos.'}
                {activeTab === 'signup' && 'Registre seu perfil funcional na rede interna.'}
                {activeTab === 'forgot' && 'Redefina sua senha de acesso.'}
              </p>
            </div>
          </div>

          {/* Alert Messages */}
          {error && (
            <div className="mb-4 p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs flex items-start gap-2 animate-pulse" id="login-error-alert">
              <ShieldAlert className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs flex items-start gap-2" id="login-success-alert">
              <CheckCircle className="w-4.5 h-4.5 text-emerald-500 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          {/* SIGN IN FORM */}
          {activeTab === 'signin' && (
            <form onSubmit={handleSignIn} className="space-y-4" id="signin-form">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 font-sans">E-mail de Acesso</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                  <input
                    type="email"
                    required
                    placeholder="seu-email@exemplo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Senha Secreta</label>
                  <button
                    type="button"
                    onClick={() => {
                      setError('');
                      setSuccess('');
                      setActiveTab('forgot');
                    }}
                    className="text-xs text-red-400 hover:text-red-300 font-semibold"
                  >
                    Esqueceu a senha?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="• • • • • •"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-400"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                id="submit-signin-btn"
                disabled={isLoading}
                className="w-full py-3 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-4"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Autenticando acesso...
                  </>
                ) : (
                  <>
                    Entrar no Sistema NUPBEEP
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center pt-4 text-xs text-slate-500">
                Não possui conta neste servidor?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setSuccess('');
                    setActiveTab('signup');
                  }}
                  className="text-red-400 hover:text-red-300 font-bold"
                >
                  Criar Conta Grátis
                </button>
              </div>
            </form>
          )}

          {/* SIGN UP FORM */}
          {activeTab === 'signup' && (
            <form onSubmit={handleSignUp} className="space-y-4" id="signup-form">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Seu Nome Completo</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                  <input
                    type="text"
                    required
                    placeholder="Ex: Marina de Sousa"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">E-mail de Acesso</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                  <input
                    type="email"
                    required
                    placeholder="seu-email@exemplo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Senha Secreta</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                    <input
                      type="password"
                      required
                      placeholder="• • • • • •"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Confirmar Senha</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                    <input
                      type="password"
                      required
                      placeholder="• • • • • •"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                id="submit-signup-btn"
                disabled={isLoading}
                className="w-full py-3 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Registrando na base de dados...
                  </>
                ) : (
                  <>
                    Registrar Conta NUPBEEP
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center pt-3 text-xs text-slate-500">
                Já tem cadastro?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setSuccess('');
                    setActiveTab('signin');
                  }}
                  className="text-red-400 hover:text-red-300 font-bold"
                >
                  Entrar aqui
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD FORM */}
          {activeTab === 'forgot' && (
            <div className="space-y-4" id="forgot-password-module">
              {simulationStep === 1 ? (
                <form onSubmit={handleResetRequest} className="space-y-4" id="forgot-step-1">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Seu E-mail Cadastrado</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                      <input
                        type="email"
                        required
                        placeholder="seu-email@exemplo.com"
                        value={resetEmail}
                        onChange={(e) => setResetEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                      />
                    </div>
                    <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
                      Utilize o seu e-mail cadastrado. Redefina a sua senha diretamente de forma segura nesta tela.
                    </p>
                  </div>

                  <button
                    type="submit"
                    id="submit-forgot-btn"
                    disabled={isLoading}
                    className="w-full py-3 bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-1"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Verificando conta...
                      </>
                    ) : (
                      <>
                        Verificar & Prosseguir
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleSaveNewPassword} className="space-y-4" id="forgot-step-2">
                  <div className="bg-red-500/5 p-3 rounded-lg border border-red-950/40 text-xs text-slate-400 flex items-start gap-2 mb-2">
                    <Key className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      Acesso verificado para: <strong className="text-red-400">{resetEmail}</strong>. Digite sua nova senha de acesso abaixo.
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Nova Senha</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                      <input
                        type="password"
                        required
                        placeholder="No mínimo 4 dígitos"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 focus:border-red-600 focus:ring-1 focus:ring-red-600 text-slate-200 placeholder-slate-600 rounded-lg text-sm focus:outline-hidden transition-all"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    id="submit-new-password-btn"
                    disabled={isLoading}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Atualizando credencial...
                      </>
                    ) : (
                      <>
                        Confirmar Nova Senha
                        <CheckCircle className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}

              <div className="text-center pt-3 text-xs text-slate-500">
                Lembrou?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setSuccess('');
                    setSimulationStep(1);
                    setResetEmail('');
                    setNewPassword('');
                    setActiveTab('signin');
                  }}
                  className="text-red-400 hover:text-red-300 font-bold"
                >
                  Voltar para o login
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
