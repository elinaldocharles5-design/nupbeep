/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Users, TrendingUp, Sparkles, Award, ArrowUpRight, ClipboardList } from 'lucide-react';
import { Collaborator, TurnoverMetric, OnboardingTalent, PerformanceEvaluation as EvalType } from '../types';

interface DashboardProps {
  collaborators: Collaborator[];
  turnoverMetrics: TurnoverMetric[];
  onboardingTalents: OnboardingTalent[];
  evaluations: EvalType[];
  onNavigate: (tab: string) => void;
}

export default function Dashboard({
  collaborators,
  turnoverMetrics,
  onboardingTalents,
  evaluations,
  onNavigate,
}: DashboardProps) {
  const activeCount = collaborators.filter((c) => c.status === 'Ativo').length;
  
  // Current onboarding count
  const onboardingCount = onboardingTalents.length;

  // Department counts
  const deptCounts: { [key: string]: number } = {};
  collaborators.forEach((c) => {
    if (c.status === 'Ativo') {
      deptCounts[c.department] = (deptCounts[c.department] || 0) + 1;
    }
  });

  const departmentData = Object.keys(deptCounts).map((dept) => ({
    name: dept,
    colaboradores: deptCounts[dept],
  }));

  // Average performance metric
  const averagePerformance = activeCount > 0
    ? (
        collaborators
          .filter((c) => c.status === 'Ativo')
          .reduce(
            (acc, c) =>
              acc +
              (c.performance.productivity +
                c.performance.competence +
                c.performance.communication +
                c.performance.alignment) /
                4,
            0
          ) / activeCount
      ).toFixed(0)
    : '0';

  return (
    <div className="space-y-6 animate-fade-in" id="dashboard-tab">
      {/* Intro Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-6 border-b border-gray-200">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            Painel Estratégico NUPBEEP
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Métricas de engajamento, retenção ativa, integração estudantil e acompanhamento de equipes de Engenharia de Produção.
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex gap-2">
          <button
            id="nav-onboarding-btn"
            onClick={() => onNavigate('onboarding')}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors border border-red-100"
          >
            Integrar Novo Membro
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid de Metricas Rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        {/* Card 1 */}
        <div className="p-5 bg-white rounded-xl border border-gray-100 shadow-xs flex items-center justify-between" id="metric-colabs">
          <div className="space-y-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Membros Ativos</span>
            <span className="text-3xl font-black text-gray-950 font-sans">{activeCount}</span>
            <span className="text-xs text-green-600 font-bold block mt-0.5">Alto engajamento técnico</span>
          </div>
          <div className="p-3 bg-red-50 rounded-xl text-red-600">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Card 2 */}
        <div className="p-5 bg-white rounded-xl border border-gray-100 shadow-xs flex items-center justify-between" id="metric-evaluations">
          <div className="space-y-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Avaliações Emitidas</span>
            <span className="text-3xl font-black text-gray-950 flex items-baseline gap-1">
              {evaluations.length}
            </span>
            <span className="text-xs text-red-650 font-bold block mt-0.5">Pareceres táticos de membros</span>
          </div>
          <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
            <ClipboardList className="w-6 h-6" />
          </div>
        </div>

        {/* Card 3 */}
        <div className="p-5 bg-white rounded-xl border border-gray-100 shadow-xs flex items-center justify-between" id="metric-performance">
          <div className="space-y-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Produtividade Geral</span>
            <span className="text-3xl font-black text-gray-950">{averagePerformance}%</span>
            <span className="text-xs text-gray-500 font-medium block mt-0.5">Entregas de projetos & metas</span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        {/* Card 4 */}
        <div className="p-5 bg-white rounded-xl border border-gray-100 shadow-xs flex items-center justify-between" id="metric-onboarding">
          <div className="space-y-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Acompanhamentos Ativos</span>
            <span className="text-3xl font-black text-gray-950">{onboardingCount}</span>
            <span className="text-xs text-red-600 font-bold block mt-0.5">Novos membros em onboarding</span>
          </div>
          <div className="p-3 bg-red-50 rounded-xl text-red-600">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Seção de Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gráfico 1: Turnover (Admissões vs Desligamentos) */}
        <div className="lg:col-span-2 p-6 bg-white rounded-2xl border border-gray-100" id="chart-turnover-panel">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-base font-bold text-gray-900">Histórico de Fluxo de Integrantes (Turnover)</h2>
              <p className="text-xs text-gray-500">Métricas de atração (admissões) versus saídas nos últimos meses</p>
            </div>
            <div className="flex gap-4 text-xs font-semibold">
              <span className="flex items-center gap-1.5 text-red-600">
                <span className="w-3 h-3 bg-red-600 rounded-xs inline-block"></span> Admissões
              </span>
              <span className="flex items-center gap-1.5 text-slate-800">
                <span className="w-3 h-3 bg-slate-950 rounded-xs inline-block"></span> Desligados
              </span>
            </div>
          </div>
          
          <div className="h-68">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={turnoverMetrics} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHired" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#b91c1c" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#b91c1c" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorTerminated" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1e293b" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#1e293b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #f1f5f9', fontSize: '12px' }}
                  labelStyle={{ fontWeight: '700' }}
                />
                <Area type="monotone" name="Admitidos" dataKey="hired" stroke="#b91c1c" strokeWidth={2.5} fillOpacity={1} fill="url(#colorHired)" />
                <Area type="monotone" name="Desligados" dataKey="terminated" stroke="#1f2937" strokeWidth={2.5} fillOpacity={1} fill="url(#colorTerminated)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Gráfico 2: Alocação de Talentos por Setor */}
        <div className="p-6 bg-white rounded-2xl border border-gray-100 flex flex-col justify-between" id="chart-departments-panel">
          <div>
            <h2 className="text-base font-bold text-gray-900">Alocação de Equipes</h2>
            <p className="text-xs text-gray-500 mb-6">Membros ativos alocados nas Diretorias de Engenharia</p>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            {departmentData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={departmentData} margin={{ left: -20, right: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis allowDecimals={false} stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <Tooltip
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #f1f5f9', fontSize: '11px' }}
                  />
                  <Bar dataKey="colaboradores" fill="#b91c1c" radius={[6, 6, 0, 0]} barSize={28} name="Total" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-sm text-gray-400">Nenhum dado de setor cadastrado.</div>
            )}
          </div>

          <div className="mt-4 pt-4 border-t border-gray-55 text-xs text-gray-400 text-center">
            Mapeamento dinâmico de diretorias e assessorias
          </div>
        </div>
      </div>

      {/* Grid Secundário: Talentos em Destaque & Alertas de PDI */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Onboarding de Olho */}
        <div className="p-6 bg-white rounded-xl border border-gray-100" id="dash-onboarding-summary">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-900 text-sm">Acompanhamento de Integração</h3>
            <button 
              id="view-all-onb-btn"
              onClick={() => onNavigate('onboarding')} 
              className="text-xs text-red-650 font-bold hover:underline cursor-pointer"
            >
              Ver todos ({onboardingTalents.length})
            </button>
          </div>

          {onboardingTalents.length === 0 ? (
            <div className="py-8 text-center text-sm text-gray-400">Nenhum onboarding ativo no momento.</div>
          ) : (
            <div className="space-y-4">
              {onboardingTalents.map((t) => (
                <div key={t.id} className="flex items-center justify-between p-3.5 bg-gray-50 rounded-lg">
                  <div>
                    <span className="font-bold text-sm text-gray-900 block">{t.name}</span>
                    <span className="text-xs text-gray-400 block">{t.role} • {t.department}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-red-750 block">{t.progress}% Concluído</span>
                    <div className="w-24 bg-gray-200 rounded-full h-1.5 mt-1 overflow-hidden">
                      <div className="bg-red-700 h-1.5 rounded-full" style={{ width: `${t.progress}%` }}></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Avaliação de Desempenho Diagnóstico Prático */}
        <div className="p-6 bg-white rounded-xl border border-gray-100 flex flex-col justify-between" id="dash-performance-summary">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900 text-sm">Desempenho de Integrantes</h3>
              <button 
                id="view-all-evals-btn"
                onClick={() => onNavigate('performance')} 
                className="text-xs text-red-650 font-bold hover:underline cursor-pointer"
              >
                Nova Avaliação
              </button>
            </div>

            <p className="text-xs text-gray-500 mb-4 leading-relaxed font-sans">
              Consolidação técnica do NUPBEEP. Membros classificados com resultado <strong>Ruim</strong> necessitam de plano PDI imediato para alinhamento e capacitação.
            </p>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-emerald-50 text-emerald-700 rounded-lg text-center" id="performance-otimo-count">
                <span className="text-xs font-bold block font-sans">Ótimo</span>
                <span className="text-lg font-bold block mt-1">
                  {evaluations.filter(e => e.result === 'Ótimo').length} aval.
                </span>
                <span className="text-[10px] text-emerald-500 block leading-tight mt-0.5">Alto Desempenho</span>
              </div>
              <div className="p-3 bg-amber-50 text-amber-700 rounded-lg text-center" id="performance-bom-count">
                <span className="text-xs font-bold block font-sans">Bom</span>
                <span className="text-lg font-bold block mt-1">
                  {evaluations.filter(e => e.result === 'Bom').length} aval.
                </span>
                <span className="text-[10px] text-amber-500 block leading-tight mt-0.5">Atende as metas</span>
              </div>
              <div className="p-3 bg-rose-50 text-rose-700 rounded-lg text-center" id="performance-ruim-count">
                <span className="text-xs font-bold block font-sans">Ruim</span>
                <span className="text-lg font-bold block mt-1">
                  {evaluations.filter(e => e.result === 'Ruim').length} aval.
                </span>
                <span className="text-[10px] text-rose-500 block leading-tight mt-0.5">PDI Requerido</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-50 flex items-center gap-1.5 text-xs text-gray-400">
            <Award className="w-3.5 h-3.5 text-red-500" />
            Vá para a guia de Avaliações de Desempenho para registrar e gerenciar pareceres.
          </div>
        </div>
      </div>
    </div>
  );
}
