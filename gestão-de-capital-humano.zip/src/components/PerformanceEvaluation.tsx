import React, { useState } from 'react';
import { Collaborator, PerformanceEvaluation as EvalType } from '../types';
import { 
  Plus, Search, Calendar, User, FileText, CheckCircle2, 
  Trash2, Award, ClipboardList, ShieldAlert, Sparkles, AlertCircle
} from 'lucide-react';

interface PerformanceEvaluationProps {
  collaborators: Collaborator[];
  evaluations: EvalType[];
  onAddEvaluation: (evaluation: Omit<EvalType, 'id'>) => void;
  onDeleteEvaluation: (id: string) => void;
}

export default function PerformanceEvaluation({
  collaborators,
  evaluations,
  onAddEvaluation,
  onDeleteEvaluation,
}: PerformanceEvaluationProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchText, setSearchText] = useState('');
  
  // Form states
  const [selectedColabId, setSelectedColabId] = useState('');
  const [evaluator, setEvaluator] = useState('');
  const [q1, setQ1] = useState<'Ruim' | 'Bom' | 'Ótimo'>('Bom');
  const [q2, setQ2] = useState<'Ruim' | 'Bom' | 'Ótimo'>('Bom');
  const [q3, setQ3] = useState<'Ruim' | 'Bom' | 'Ótimo'>('Bom');
  const [q4, setQ4] = useState<'Ruim' | 'Bom' | 'Ótimo'>('Bom');
  const [comments, setComments] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  // Active collaborators for dropdown selection
  const activeColabs = collaborators.filter(c => c.status === 'Ativo');

  // Logic to calculate overall result automatically based on the selected answers
  const calculateResult = (
    ans1: 'Ruim' | 'Bom' | 'Ótimo', 
    ans2: 'Ruim' | 'Bom' | 'Ótimo', 
    ans3: 'Ruim' | 'Bom' | 'Ótimo', 
    ans4: 'Ruim' | 'Bom' | 'Ótimo'
  ): 'Ruim' | 'Bom' | 'Ótimo' => {
    const scoreMap = { Ruim: 1, Bom: 2, Ótimo: 3 };
    const sum = scoreMap[ans1] + scoreMap[ans2] + scoreMap[ans3] + scoreMap[ans4];
    if (sum <= 6) return 'Ruim';
    if (sum >= 10) return 'Ótimo';
    return 'Bom';
  };

  const currentResult = calculateResult(q1, q2, q3, q4);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedColabId || !evaluator.trim()) {
      alert('Por favor, selecione um integrante e preencha o nome do avaliador.');
      return;
    }

    const colab = activeColabs.find(c => c.id === selectedColabId);
    if (!colab) return;

    onAddEvaluation({
      collaboratorId: colab.id,
      collaboratorName: colab.name,
      department: colab.department,
      role: colab.role,
      date,
      q1,
      q2,
      q3,
      q4,
      result: currentResult,
      comments,
      evaluator,
    });

    // Reset Form
    setSelectedColabId('');
    setEvaluator('');
    setQ1('Bom');
    setQ2('Bom');
    setQ3('Bom');
    setQ4('Bom');
    setComments('');
    setShowAddForm(false);
  };

  // Dashboard Stats
  const totalEvals = evaluations.length;
  const ruimCount = evaluations.filter(e => e.result === 'Ruim').length;
  const bomCount = evaluations.filter(e => e.result === 'Bom').length;
  const otimoCount = evaluations.filter(e => e.result === 'Ótimo').length;

  const filteredEvaluations = evaluations.filter(e => 
    e.collaboratorName.toLowerCase().includes(searchText.toLowerCase()) ||
    e.evaluator.toLowerCase().includes(searchText.toLowerCase()) ||
    e.department.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in" id="performance-tab">
      
      {/* Tab Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-6 border-b border-gray-200 gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            Avaliação de Desempenho
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Realize e gerencie as avaliações de desempenho dos membros ativos do NUPBEEP com métricas qualificadas.
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2.5 bg-red-700 text-white rounded-lg text-xs font-black hover:bg-red-800 transition-all flex items-center gap-2 cursor-pointer shadow-xs self-start"
        >
          {showAddForm ? 'Visualizar Histórico' : 'Nova Avaliação'}
          <Plus className={`w-4 h-4 transition-transform ${showAddForm ? 'rotate-45' : ''}`} />
        </button>
      </div>

      {/* Overview Cards (Only shown when not in the form Mode) */}
      {!showAddForm && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white rounded-xl border border-gray-100 shadow-xs flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Total de Avaliações</span>
              <span className="text-2xl font-black text-slate-900">{totalEvals}</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Histórico consolidado</span>
            </div>
            <div className="p-2.5 bg-slate-50 text-slate-600 rounded-lg">
              <ClipboardList className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block">Desempenho Ótimo</span>
              <span className="text-2xl font-black text-emerald-900">{otimoCount}</span>
              <span className="text-[10px] text-emerald-600 block mt-0.5">Alto desempenho</span>
            </div>
            <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-lg">
              <Award className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 bg-amber-50 rounded-xl border border-amber-100 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-bold text-amber-800 uppercase tracking-wider block">Desempenho Bom</span>
              <span className="text-2xl font-black text-amber-900">{bomCount}</span>
              <span className="text-[10px] text-amber-600 block mt-0.5">Alinhado com as expectativas</span>
            </div>
            <div className="p-2.5 bg-amber-100 text-amber-700 rounded-lg">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 bg-rose-50 rounded-xl border border-rose-100 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-bold text-rose-800 uppercase tracking-wider block">Desempenho Ruim</span>
              <span className="text-2xl font-black text-rose-900">{ruimCount}</span>
              <span className="text-[10px] text-rose-600 block mt-0.5">Necessitam de plano PDI</span>
            </div>
            <div className="p-2.5 bg-rose-100 text-rose-700 rounded-lg">
              <ShieldAlert className="w-5 h-5" />
            </div>
          </div>
        </div>
      )}

      {/* Core Panels */}
      {showAddForm ? (
        <form onSubmit={handleSubmit} className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto" id="new-evaluation-form">
          <div className="border-b border-gray-100 pb-4">
            <h2 className="text-base font-extrabold text-slate-900 uppercase">Preencher Ficha de Avaliação</h2>
            <p className="text-xs text-gray-500 mt-0.5">Responda aos critérios abaixo técnica e honestamente.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1.5">Membro Integrante *</label>
              <select
                required
                value={selectedColabId}
                onChange={(e) => setSelectedColabId(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-white border border-gray-200 rounded-lg text-slate-800 focus:border-red-650"
              >
                <option value="">-- Selecione o Integrante --</option>
                {activeColabs.map((colab) => (
                  <option key={colab.id} value={colab.id}>
                    {colab.name} ({colab.department})
                  </option>
                ))}
              </select>
              {activeColabs.length === 0 && (
                <span className="text-[10px] text-amber-600 block mt-1">⚠️ Cadastre integrantes ativos antes para poder avaliar.</span>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1.5 font-sans">Avaliador Responsável *</label>
              <input
                type="text"
                required
                placeholder="Ex. Coordenador Gente e Gestão"
                value={evaluator}
                onChange={(e) => setEvaluator(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-white border border-gray-250 rounded-lg text-slate-850 focus:border-red-650 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] font-black text-slate-500 uppercase mb-1.5">Data da Avaliação</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-xs font-bold p-2.5 bg-white border border-gray-250 rounded-lg text-slate-850"
              />
            </div>
          </div>

          {/* Question Criteria Block */}
          <div className="space-y-5 pt-4 border-t border-gray-50">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Critérios e Perguntas de Desempenho</h3>
            
            {/* Q1 */}
            <div className="p-4 bg-slate-50/50 rounded-xl border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <span className="text-[10px] font-black text-red-700 uppercase tracking-wider block">Métrica 1: Entregas e Produtividade</span>
                <p className="text-xs font-bold text-slate-900">Como você avalia a qualidade, agilidade e execução no cumprimento de tarefas e metas propostas?</p>
              </div>
              <div className="flex bg-white border border-gray-200 rounded-lg p-0.5 shrink-0 self-start md:self-auto">
                {(['Ruim', 'Bom', 'Ótimo'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setQ1(opt)}
                    className={`px-4 py-1.5 text-xs font-extrabold rounded-md transition-all cursor-pointer ${
                      q1 === opt 
                        ? opt === 'Ruim' ? 'bg-rose-600 text-white' : opt === 'Bom' ? 'bg-amber-500 text-white' : 'bg-emerald-600 text-white'
                        : 'text-gray-500 hover:bg-gray-100'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Q2 */}
            <div className="p-4 bg-slate-50/50 rounded-xl border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <span className="text-[10px] font-black text-red-700 uppercase tracking-wider block">Métrica 2: Comprometimento e Proatividade</span>
                <p className="text-xs font-bold text-slate-900">Demonstra iniciativa ao propor soluções e se mantém presente nas reuniões e atividades internas?</p>
              </div>
              <div className="flex bg-white border border-gray-200 rounded-lg p-0.5 shrink-0 self-start md:self-auto">
                {(['Ruim', 'Bom', 'Ótimo'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setQ2(opt)}
                    className={`px-4 py-1.5 text-xs font-extrabold rounded-md transition-all cursor-pointer ${
                      q2 === opt 
                        ? opt === 'Ruim' ? 'bg-rose-600 text-white' : opt === 'Bom' ? 'bg-amber-500 text-white' : 'bg-emerald-600 text-white'
                        : 'text-gray-500 hover:bg-gray-100'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Q3 */}
            <div className="p-4 bg-slate-50/50 rounded-xl border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <span className="text-[10px] font-black text-red-700 uppercase tracking-wider block">Métrica 3: Trabalho em Equipe e Cooperação</span>
                <p className="text-xs font-bold text-slate-900">Como avalia a comunicação institucional do integrante, boa vontade técnica e cooperatividade com outros membros?</p>
              </div>
              <div className="flex bg-white border border-gray-200 rounded-lg p-0.5 shrink-0 self-start md:self-auto">
                {(['Ruim', 'Bom', 'Ótimo'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setQ3(opt)}
                    className={`px-4 py-1.5 text-xs font-extrabold rounded-md transition-all cursor-pointer ${
                      q3 === opt 
                        ? opt === 'Ruim' ? 'bg-rose-600 text-white' : opt === 'Bom' ? 'bg-amber-500 text-white' : 'bg-emerald-600 text-white'
                        : 'text-gray-500 hover:bg-gray-100'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Q4 */}
            <div className="p-4 bg-slate-50/50 rounded-xl border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <span className="text-[10px] font-black text-red-700 uppercase tracking-wider block">Métrica 4: Alinhamento Cultural ao NUPBEEP</span>
                <p className="text-xs font-bold text-slate-900">Sua postura converge com a ética profissional exigida pelas diretorias do Núcleo de Engenharia de Produção?</p>
              </div>
              <div className="flex bg-white border border-gray-200 rounded-lg p-0.5 shrink-0 self-start md:self-auto">
                {(['Ruim', 'Bom', 'Ótimo'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setQ4(opt)}
                    className={`px-4 py-1.5 text-xs font-extrabold rounded-md transition-all cursor-pointer ${
                      q4 === opt 
                        ? opt === 'Ruim' ? 'bg-rose-600 text-white' : opt === 'Bom' ? 'bg-amber-500 text-white' : 'bg-emerald-600 text-white'
                        : 'text-gray-500 hover:bg-gray-100'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Dynamic Calculated Outcome Feedback banner */}
          <div className="p-4 rounded-xl border flex items-center gap-3.5 bg-slate-50 border-slate-200">
            <div className={`p-2.5 rounded-lg shrink-0 ${
              currentResult === 'Ótimo' ? 'bg-emerald-100 text-emerald-800' :
              currentResult === 'Bom' ? 'bg-amber-100 text-amber-850' :
              'bg-red-100 text-red-800'
            }`}>
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 block">Resultado Geral Calculado</span>
              <span className="text-sm font-black flex items-center gap-1.5">
                Desempenho Geral: 
                <span className={`px-2 py-0.5 rounded text-xs px-2.5 font-bold ${
                  currentResult === 'Ótimo' ? 'bg-emerald-100 text-emerald-850' :
                  currentResult === 'Bom' ? 'bg-amber-50 text-amber-850 font-extrabold' :
                  'bg-red-50 text-red-850 font-black'
                }`}>{currentResult === 'Ótimo' ? '🟢 ÓTIMO' : currentResult === 'Bom' ? '🟡 BOM' : '🔴 RUIM'}</span>
              </span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-black text-slate-500 uppercase mb-1.5">Anotações Complementares & Plano PDI</label>
            <textarea
              rows={4}
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="Descreva pontos fortes observados, conselhos táticos ou próximos passos de alinhamento..."
              className="w-full text-xs font-medium p-3 bg-white border border-gray-250 rounded-lg text-slate-800 focus:border-red-650"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-205 text-slate-600 bg-white hover:bg-slate-50 rounded-lg text-xs font-extrabold cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-red-750 text-white hover:bg-red-800 rounded-lg text-xs font-black cursor-pointer shadow-xs"
            >
              Salvar Avaliação
            </button>
          </div>
        </form>
      ) : (
        /* History lists Panel */
        <div className="bg-white border border-gray-100 rounded-xl shadow-xs p-6 space-y-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-extrabold text-slate-950 font-sans">Histórico de Pareceres de Desempenho</h2>
              <p className="text-xs text-slate-400">Verifique e exclua avaliações arquivadas.</p>
            </div>

            {/* Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-2.5 w-4.5 h-4.5 text-gray-400" />
              <input
                type="text"
                placeholder="Filtrar por nome ou avaliador..."
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50/50 border border-gray-200 focus:bg-white focus:outline-hidden text-xs font-medium rounded-lg"
              />
            </div>
          </div>

          {filteredEvaluations.length === 0 ? (
            <div className="py-16 text-center text-gray-400 flex flex-col items-center justify-center">
              <FileText className="w-12 h-12 text-slate-200 mb-2" />
              <span className="text-sm font-bold">Nenhuma avaliação encontrada</span>
              <p className="text-xs text-gray-400 mt-1 max-w-sm">Use o botão "Nova Avaliação" para cadastrar o parecer acadêmico preliminar do NUPBEEP.</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-gray-100">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-[10px] font-black text-slate-500 uppercase tracking-wider border-b border-gray-100">
                    <th className="p-4">Integrante</th>
                    <th className="p-4">Diretoria</th>
                    <th className="p-4">Data</th>
                    <th className="p-4">Métricas Q1 - Q4</th>
                    <th className="p-4">Resultado Geral</th>
                    <th className="p-4">Avaliador / Observações</th>
                    <th className="p-4 text-center">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs">
                  {filteredEvaluations.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/40 transition-colors">
                      <td className="p-4">
                        <div className="font-bold text-slate-900">{item.collaboratorName}</div>
                        <div className="text-[10px] text-slate-400">{item.role}</div>
                      </td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-bold rounded text-[10px]">
                          Diretoria de {item.department}
                        </span>
                      </td>
                      <td className="p-4 text-slate-550 font-semibold font-mono">
                        {new Date(item.date).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="p-4">
                        <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 text-[10px]">
                          <div><span className="text-slate-400">Prod:</span> <span className="font-bold">{item.q1}</span></div>
                          <div><span className="text-slate-400">Proat:</span> <span className="font-bold">{item.q2}</span></div>
                          <div><span className="text-slate-400">Equip:</span> <span className="font-bold">{item.q3}</span></div>
                          <div><span className="text-slate-400">Cult:</span> <span className="font-bold">{item.q4}</span></div>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-black inline-block whitespace-nowrap ${
                          item.result === 'Ruim' ? 'bg-red-50 text-red-700' :
                          item.result === 'Bom' ? 'bg-amber-50 text-amber-700' :
                          'bg-emerald-50 text-emerald-700'
                        }`}>
                          {item.result === 'Ruim' ? '🔴 Ruim' : item.result === 'Bom' ? '🟡 Bom' : '🟢 Ótimo'}
                        </span>
                      </td>
                      <td className="p-4 max-w-xs">
                        <div className="font-bold text-slate-800">Avaliado por: {item.evaluator}</div>
                        {item.comments && (
                          <div className="text-[10px] text-gray-500 italic truncate mt-0.5" title={item.comments}>
                            "{item.comments}"
                          </div>
                        )}
                      </td>
                      <td className="p-4 text-center">
                        <button
                          onClick={() => {
                            if (confirm('Tem certeza que deseja excluir esta avaliação de desempenho permanentemente?')) {
                              onDeleteEvaluation(item.id);
                            }
                          }}
                          className="p-1 px-1.5 text-gray-400 hover:text-red-700 hover:bg-red-50 rounded transition-colors cursor-pointer"
                          title="Excluir Avaliação"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
