/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Collaborator {
  id: string;
  name: string;
  role: string;
  department: string;
  admissionDate: string;
  email: string;
  status: 'Ativo' | 'Afastado' | 'Desligado';
  performance: {
    productivity: number; // 0 to 100
    competence: number; // 0 to 100
    communication: number; // 0 to 100
    alignment: number; // 0 to 100
    lastReviewDate: string;
    pdiNotes: string; // Individual Development Plan
  };
  engagement: {
    moraleScore: number; // 1 to 5
    lastSurveyDate: string;
    surveyFeedback: string;
  };
}

export interface MeetingMinute {
  id: string;
  title: string;
  date: string;
  participants: string;
  rawNotes: string;
  aiSummary?: string;
  actionItems?: string[];
  createdAt: string;
}

export interface TurnoverMetric {
  month: string;
  hired: number;
  terminated: number;
  rate: number; // percentage
}

export interface OnboardingTask {
  id: string;
  title: string;
  category: 'Documentos' | 'Treinamento' | 'Equipamentos' | 'Integração';
  completed: boolean;
}

export interface OnboardingTalent {
  id: string;
  name: string;
  role: string;
  department: string;
  startDate: string;
  email: string;
  avatarColor: string;
  progress: number; // percentage
  tasks: OnboardingTask[];
  aiPlan?: string; // AI Custom Onboarding Roadmap
}

export interface PerformanceEvaluation {
  id: string;
  collaboratorId: string;
  collaboratorName: string;
  department: string;
  role: string;
  date: string;
  q1: 'Ruim' | 'Bom' | 'Ótimo'; // Entregas e Produtividade
  q2: 'Ruim' | 'Bom' | 'Ótimo'; // Comprometimento e Proatividade
  q3: 'Ruim' | 'Bom' | 'Ótimo'; // Comunicação e Trabalho em Equipe
  q4: 'Ruim' | 'Bom' | 'Ótimo'; // Alinhamento Cultural
  result: 'Ruim' | 'Bom' | 'Ótimo';
  comments: string;
  evaluator: string;
}

