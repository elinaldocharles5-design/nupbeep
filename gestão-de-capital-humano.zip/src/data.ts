/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Collaborator, MeetingMinute, TurnoverMetric, OnboardingTalent } from './types';

export const INITIAL_COLLABORATORS: Collaborator[] = [];

export const INITIAL_MINUTES: MeetingMinute[] = [];

export const INITIAL_TURNOVER_METRICS: TurnoverMetric[] = [
  { month: 'Dez', hired: 0, terminated: 0, rate: 0 },
  { month: 'Jan', hired: 0, terminated: 0, rate: 0 },
  { month: 'Fev', hired: 0, terminated: 0, rate: 0 },
  { month: 'Mar', hired: 0, terminated: 0, rate: 0 },
  { month: 'Abr', hired: 0, terminated: 0, rate: 0 },
  { month: 'Mai', hired: 0, terminated: 0, rate: 0 }
];

export const INITIAL_ONBOARDING_TALENTS: OnboardingTalent[] = [];

export function getLocalData<T>(key: string, initialData: T): T {
  const stored = localStorage.getItem(key);
  if (!stored) {
    localStorage.setItem(key, JSON.stringify(initialData));
    return initialData;
  }
  try {
    return JSON.parse(stored);
  } catch {
    return initialData;
  }
}

export function saveLocalData<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data));
}
