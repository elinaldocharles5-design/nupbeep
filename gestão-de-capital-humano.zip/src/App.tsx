/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  INITIAL_COLLABORATORS, 
  INITIAL_MINUTES, 
  INITIAL_TURNOVER_METRICS, 
  INITIAL_ONBOARDING_TALENTS,
  getLocalData,
  saveLocalData 
} from './data';
import { 
  Collaborator, 
  MeetingMinute, 
  TurnoverMetric, 
  OnboardingTalent,
  PerformanceEvaluation as EvalType
} from './types';

// Importing Tab Components
import Dashboard from './components/Dashboard';
import Collaborators from './components/Collaborators';
import PerformanceEvaluation from './components/PerformanceEvaluation';
import MeetingMinutes from './components/MeetingMinutes';
import Onboarding from './components/Onboarding';
import Login, { NupbeepLogo } from './components/Login';

// Lucide Icons Import
import { 
  LayoutDashboard, Users, HeartHandshake, FileText, 
  Sparkles, CheckSquare, CloudLightning, RefreshCw, LogOut, User,
  Award
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // Authenticated User State
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string } | null>(() => {
    try {
      const saved = localStorage.getItem('hcm_logged_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // State Management
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [minutes, setMinutes] = useState<MeetingMinute[]>([]);
  const [turnoverMetrics, setTurnoverMetrics] = useState<TurnoverMetric[]>([]);
  const [onboardingTalents, setOnboardingTalents] = useState<OnboardingTalent[]>([]);
  const [evaluations, setEvaluations] = useState<EvalType[]>([]);

  // Load state on mount with automatic one-time cleanup of old mock sessions
  useEffect(() => {
    const isCleaned = localStorage.getItem('hcm_clean_v5');
    if (!isCleaned) {
      localStorage.removeItem('hcm_collaborators');
      localStorage.removeItem('hcm_minutes');
      localStorage.removeItem('hcm_turnover');
      localStorage.removeItem('hcm_onboarding');
      localStorage.removeItem('hcm_evaluations');
      localStorage.setItem('hcm_clean_v5', 'true');
    }

    setCollaborators(getLocalData<Collaborator[]>('hcm_collaborators', INITIAL_COLLABORATORS));
    setMinutes(getLocalData<MeetingMinute[]>('hcm_minutes', INITIAL_MINUTES));
    setTurnoverMetrics(getLocalData<TurnoverMetric[]>('hcm_turnover', INITIAL_TURNOVER_METRICS));
    setOnboardingTalents(getLocalData<OnboardingTalent[]>('hcm_onboarding', INITIAL_ONBOARDING_TALENTS));
    setEvaluations(getLocalData<EvalType[]>('hcm_evaluations', []));
  }, []);

  // Sync to local storage on changes
  const updateAndSaveColabs = (data: Collaborator[]) => {
    setCollaborators(data);
    saveLocalData('hcm_collaborators', data);
  };

  const updateAndSaveMinutes = (data: MeetingMinute[]) => {
    setMinutes(data);
    saveLocalData('hcm_minutes', data);
  };

  const updateAndSaveTurnover = (data: TurnoverMetric[]) => {
    setTurnoverMetrics(data);
    saveLocalData('hcm_turnover', data);
  };

  const updateAndSaveOnboarding = (data: OnboardingTalent[]) => {
    setOnboardingTalents(data);
    saveLocalData('hcm_onboarding', data);
  };

  // --- HANDLERS ---

  // Add collaborator
  const handleAddCollaborator = (newC: Omit<Collaborator, 'id'>) => {
    const id = `colab-${Date.now()}`;
    const added: Collaborator = { ...newC, id };
    const updated = [added, ...collaborators];
    updateAndSaveColabs(updated);

    // Update Turnover Matrix (dynamic simulation: hire incremented for May 'Mai' 2026)
    const updatedTurnover = turnoverMetrics.map((t) => {
      if (t.month === 'Mai') {
        const h = t.hired + 1;
        // recalculate basic rate (attritions/headcount * 100) or just add
        return { ...t, hired: h, rate: parseFloat(((t.terminated / (collaborators.length + 1)) * 100).toFixed(1)) };
      }
      return t;
    });
    updateAndSaveTurnover(updatedTurnover);
  };

  // Update collaborator performance, status, PDI
  const handleUpdateCollaborator = (updatedC: Collaborator) => {
    const original = collaborators.find((c) => c.id === updatedC.id);
    const updatedList = collaborators.map((c) => (c.id === updatedC.id ? updatedC : c));
    updateAndSaveColabs(updatedList);

    // If status transitioned to "Desligado" (Terminated) from another status
    if (original && original.status !== 'Desligado' && updatedC.status === 'Desligado') {
      const updatedTurnover = turnoverMetrics.map((t) => {
        if (t.month === 'Mai') {
          const term = t.terminated + 1;
          const totalAtivo = updatedList.filter(x => x.status === 'Ativo').length || 1;
          const rate = parseFloat(((term / totalAtivo) * 100).toFixed(1));
          return { ...t, terminated: term, rate };
        }
        return t;
      });
      updateAndSaveTurnover(updatedTurnover);
    }
  };

  // Add performance evaluation
  const handleAddEvaluation = (newEval: Omit<EvalType, 'id'>) => {
    const id = `eval-${Date.now()}`;
    const added: EvalType = { ...newEval, id };
    const updated = [added, ...evaluations];
    setEvaluations(updated);
    saveLocalData('hcm_evaluations', updated);

    // Update collaborator's performance metrics based on evaluation scores:
    // Ruim = 50, Bom = 80, Ótimo = 100
    const scoreMap = { Ruim: 50, Bom: 80, Ótimo: 100 };
    const updatedList = collaborators.map((c) => {
      if (c.id === newEval.collaboratorId) {
        return {
          ...c,
          performance: {
            ...c.performance,
            productivity: scoreMap[newEval.q1],
            competence: scoreMap[newEval.q2],
            communication: scoreMap[newEval.q3],
            alignment: scoreMap[newEval.q4],
            lastReviewDate: newEval.date,
            pdiNotes: newEval.comments || c.performance.pdiNotes
          }
        };
      }
      return c;
    });
    updateAndSaveColabs(updatedList);
  };

  // Delete performance evaluation
  const handleDeleteEvaluation = (evalId: string) => {
    const updated = evaluations.filter((e) => e.id !== evalId);
    setEvaluations(updated);
    saveLocalData('hcm_evaluations', updated);
  };

  // Add minute logs
  const handleAddMinute = (m: Omit<MeetingMinute, 'id' | 'createdAt'>) => {
    const newM: MeetingMinute = {
      ...m,
      id: `minute-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    updateAndSaveMinutes([newM, ...minutes]);
  };

  // Update minute log
  const handleUpdateMinute = (updatedM: MeetingMinute) => {
    updateAndSaveMinutes(minutes.map((m) => (m.id === updatedM.id ? updatedM : m)));
  };

  // Delete minor logs
  const handleDeleteMinute = (minuteId: string) => {
    updateAndSaveMinutes(minutes.filter((m) => m.id !== minuteId));
  };

  // Update onboarding target checklists or planning
  const handleUpdateTalent = (t: OnboardingTalent) => {
    updateAndSaveOnboarding(onboardingTalents.map((item) => (item.id === t.id ? t : item)));
  };

  // Create new recruit in pipeline
  const handleAddTalent = (newT: Omit<OnboardingTalent, 'id' | 'progress'>) => {
    const fresh: OnboardingTalent = {
      ...newT,
      id: `onb-${Date.now()}`,
      progress: 0
    };
    updateAndSaveOnboarding([fresh, ...onboardingTalents]);
  };

  // Convert onboarding talent into a real Active Employee
  const handlePromoteToCollaborator = (talentId: string) => {
    const talentObj = onboardingTalents.find((t) => t.id === talentId);
    if (!talentObj) return;

    // Remove from Onboarding pipeline
    const filteredOnb = onboardingTalents.filter((t) => t.id !== talentId);
    updateAndSaveOnboarding(filteredOnb);

    // Promote to standard active collaborator list
    handleAddCollaborator({
      name: talentObj.name,
      role: talentObj.role,
      department: talentObj.department,
      admissionDate: new Date().toISOString().split('T')[0],
      email: talentObj.email,
      status: 'Ativo',
      performance: {
        productivity: 85,
        competence: 85,
        communication: 80,
        alignment: 90,
        lastReviewDate: new Date().toISOString().split('T')[0],
        pdiNotes: `Integração e efetivação bem sucedida do processo de Onboarding em ${new Date().toLocaleDateString('pt-BR')}.`
      },
      engagement: {
        moraleScore: 5,
        lastSurveyDate: new Date().toISOString().split('T')[0],
        surveyFeedback: 'Me sinto extremamente bem-vindo e feliz com a conclusão da trilha de integração.'
      }
    });

    setActiveTab('collaborators');
  };

  // Clear or Reset State
  const handleClearPersistence = () => {
    if (confirm('Deseja limpar todos os dados cadastrados no aplicativo? Esta ação não pode ser desfeita.')) {
      localStorage.removeItem('hcm_collaborators');
      localStorage.removeItem('hcm_minutes');
      localStorage.removeItem('hcm_turnover');
      localStorage.removeItem('hcm_onboarding');
      localStorage.removeItem('hcm_evaluations');
      
      setCollaborators(INITIAL_COLLABORATORS);
      setMinutes(INITIAL_MINUTES);
      setTurnoverMetrics(INITIAL_TURNOVER_METRICS);
      setOnboardingTalents(INITIAL_ONBOARDING_TALENTS);
      setEvaluations([]);
      
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('hcm_logged_user');
    setCurrentUser(null);
  };

  if (!currentUser) {
    return (
      <Login 
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          localStorage.setItem('hcm_logged_user', JSON.stringify(user));
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans text-gray-800" id="main-root">
      
      {/* Sleek Top Banner for App Context */}
      <header className="bg-white border-b border-gray-200/80 sticky top-0 z-50 shadow-xs" id="primary-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <NupbeepLogo className="w-11 h-11 shrink-0" />
            <div>
              <span className="font-black text-lg tracking-tight text-slate-900 block leading-tight">NUPBEEP Paraíba</span>
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider leading-none mt-1">Núcleo de Estudantes de Engenharia de Produção</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Status Sync Info */}
            <div className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-700 rounded-full text-xs font-semibold border border-red-100">
              <span className="w-1.5 h-1.5 bg-red-600 rounded-full animate-ping"></span>
              Servidor NUPBEEP Ativo
            </div>

            {/* Profile indicator directly inside the header */}
            <div className="hidden md:flex flex-col items-end text-right">
              <span className="text-xs font-bold text-gray-900 leading-none">{currentUser.name}</span>
              <span className="text-[10px] text-gray-400 mt-1 font-medium">{currentUser.email}</span>
            </div>

            <button
              id="reset-demo-databases"
              onClick={handleClearPersistence}
              title="Limpar Todos os Dados Cadastrados"
              className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-red-700 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* Logout button */}
            <button
              id="account-logout-btn"
              onClick={handleLogout}
              title="Sair do Portal"
              className="p-2 bg-rose-50 hover:bg-rose-100 rounded-lg text-red-700 border border-rose-150 transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col lg:flex-row gap-6">
        
        {/* Sidebar Navigation */}
        <aside className="lg:w-64 shrink-0" id="left-sidebar">
          <nav className="bg-white border border-gray-100 rounded-xl p-3.5 space-y-1.5 sticky top-22 shadow-xs">
            
            {/* Nav Title */}
            <div className="px-3 py-1 pb-2 border-b border-gray-50 text-xs font-bold text-slate-400 uppercase tracking-widest">
              Navegação
            </div>

            {/* Link 1: Dashboard */}
            <button
              id="sidebar-tab-dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'dashboard' 
                  ? 'bg-red-700 text-white shadow-xs' 
                  : 'text-gray-500 hover:text-red-700 hover:bg-red-50/50'
              }`}
            >
              <LayoutDashboard className="w-4.5 h-4.5" />
              Painel Estratégico
            </button>

            {/* Link 2: Collaborators */}
            <button
              id="sidebar-tab-collaborators"
              onClick={() => setActiveTab('collaborators')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'collaborators' 
                  ? 'bg-red-700 text-white shadow-xs' 
                  : 'text-gray-500 hover:text-red-700 hover:bg-red-50/50'
              }`}
            >
              <Users className="w-4.5 h-4.5" />
              Gestão de Pessoas
            </button>

            {/* Link 3: Onboarding / Integration */}
            <button
              id="sidebar-tab-onboarding"
              onClick={() => setActiveTab('onboarding')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'onboarding' 
                  ? 'bg-red-700 text-white shadow-xs' 
                  : 'text-gray-500 hover:text-red-700 hover:bg-red-50/50'
              }`}
            >
              <CheckSquare className="w-4.5 h-4.5" />
              Onboarding / Integração
            </button>

            {/* Link 4: Performance Evaluations */}
            <button
              id="sidebar-tab-performance"
              onClick={() => setActiveTab('performance')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'performance' 
                  ? 'bg-red-700 text-white shadow-xs' 
                  : 'text-gray-500 hover:text-red-700 hover:bg-red-50/50'
              }`}
            >
              <Award className="w-4.5 h-4.5 text-amber-500" />
              Avaliação de Desempenho
            </button>

            {/* Link 5: Meeting Minutes */}
            <button
              id="sidebar-tab-minutes"
              onClick={() => setActiveTab('minutes')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                activeTab === 'minutes' 
                  ? 'bg-red-700 text-white shadow-xs' 
                  : 'text-gray-500 hover:text-red-700 hover:bg-red-50/50'
              }`}
            >
              <FileText className="w-4.5 h-4.5" />
              Registro de Atas
            </button>

            {/* Disclaimer segment */}
            <div className="pt-4 border-t border-gray-55 text-[10px] text-gray-400 px-3 leading-relaxed">
              Modelagem assistida por <strong>Gemini 3.5 Flash</strong> e análise de dados em Engenharia de Produção.
            </div>

          </nav>
        </aside>

        {/* Dynamic View Tab Body */}
        <section className="flex-1 bg-transparent" id="viewport-container">
          {activeTab === 'dashboard' && (
            <Dashboard 
              collaborators={collaborators}
              turnoverMetrics={turnoverMetrics}
              onboardingTalents={onboardingTalents}
              evaluations={evaluations}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'collaborators' && (
            <Collaborators 
              collaborators={collaborators}
              onAddCollaborator={handleAddCollaborator}
              onUpdateCollaborator={handleUpdateCollaborator}
            />
          )}

          {activeTab === 'onboarding' && (
            <Onboarding 
              talents={onboardingTalents}
              onAddTalent={handleAddTalent}
              onUpdateTalent={handleUpdateTalent}
              onPromoteToCollaborator={handlePromoteToCollaborator}
            />
          )}

          {activeTab === 'performance' && (
            <PerformanceEvaluation 
              collaborators={collaborators}
              evaluations={evaluations}
              onAddEvaluation={handleAddEvaluation}
              onDeleteEvaluation={handleDeleteEvaluation}
            />
          )}

          {activeTab === 'minutes' && (
            <MeetingMinutes 
              minutes={minutes}
              onAddMinute={handleAddMinute}
              onUpdateMinute={handleUpdateMinute}
              onDeleteMinute={handleDeleteMinute}
            />
          )}
        </section>

      </main>

      {/* Sleek Minimalist Footer */}
      <footer className="bg-white border-t border-gray-100 py-6 text-center mt-12 text-xs text-gray-400" id="primary-footer">
        <p>© 2026 Portal de Controle de Capital Humano & Engajamento. Desenvolvido para governança ágil.</p>
      </footer>
    </div>
  );
}
